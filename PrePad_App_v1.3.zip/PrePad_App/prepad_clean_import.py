#!/usr/bin/env python3
"""
PrePad clean-import builder  (v2.2)
=================================

Reads a customer completions schedule (Excel), checks every well and pad, and writes:

  1. Three PrePad import files (Stage Design, Well Design, Pad) containing ONLY clean data. Stage and Well
     Designs are judged well by well; the Pad file rolls them up (a pad is written only when all its wells are ready).
  2. An internal error report: every flagged well and pad, each issue, likely cause, suggested correction,
     stage-count check, asset-mapping coverage and the data still missing for PrePad (e.g. Pumping Plan).
  3. A client review copy of the schedule in its original layout: flagged cells highlighted with comments,
     plus columns for QC status, reasoning, suggested correction, stage count and the client's response.
     This is the file sent to the client for verification and final approval.

Quick start (Windows)
---------------------
    pip install openpyxl
    python prepad_clean_import.py                                  # default folder, default thresholds
    python prepad_clean_import.py --init-config prepad_config.json # write a config pre-filled from the schedule
    python prepad_clean_import.py --config prepad_config.json      # thresholds + asset mapping from the file
    python prepad_clean_import.py --config prepad_config.json --interactive --engineer "V. Zatonski"
    python prepad_clean_import.py --resolutions output_x\\resolutions_x.json   # replay accepted corrections

Configuration (precedence: built-in DEFAULTS < --config JSON file < command-line arguments)
--------------------------------------------------------------------------------------------
* thresholds    LL screen, stage-count range, SPE minimum stage spacing, absolute LL limits. Raise
                stage_count_max for 15,000 ft+ laterals, or set ll_min_ft / ll_max_ft explicitly.
* settings      pad naming, start-date source and UTC offset, PrePad stage-design modes, date order,
                whether "Pending Review" designs block import.
* bench_aliases naming convention for benches (e.g. "WolfCamp A Lower" -> "WCA Lower").
* asset_mapping rules that fill PrePad-only fields: Pumping Plan, Casing Design, Subsurface Equipment,
                Frac Spread, Wireline, Launcher, prioritisation. First matching rule wins; see DEFAULTS.

Interactive batch resolution (--interactive)
--------------------------------------------
Suggested corrections are grouped into batches (e.g. "V51:V91 cluster spacing 25 -> 250, 41 wells").
For each batch: [a]ccept all, [r]eview one by one, [s]kip, [q]uit. Accepted corrections are applied to the
data in memory (the schedule file is never changed), the analysis is re-run, and the import files are built
from the corrected data. Every accepted change is written to resolutions_<stamp>.json with the engineer's name
and time; --resolutions replays that file on a later run (a correction is skipped if the source cell changed).
Accepted corrections are still shown to the client as "pending your confirmation".

Rules
-----
* ERROR holds the template it affects for that well (Stage Design, Well Design or Pad data); a Well Design also
  needs its Stage Design, and a pad is imported only if all its wells are ready for all three (PrePad imports whole pads).
* Nothing is corrected or defaulted unless an engineer accepts the correction (interactive or replay file).
* Thresholds are SCREENS for flagging, not design limits. Units are written as stated in the schedule.
* The source workbook is opened read-only and never saved.
"""

import argparse
import copy as copymod
import datetime as dt
import glob
import json
import os
import re
import shutil
import statistics
import sys
from collections import Counter, defaultdict

try:
    from openpyxl import Workbook, load_workbook
    from openpyxl.cell.cell import MergedCell
    from openpyxl.comments import Comment
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.datavalidation import DataValidation
except ImportError:
    sys.exit("openpyxl is required:  pip install openpyxl")

VERSION = "2.2"

# =====================================================================================
# CONFIGURATION - defaults; override with --config <file.json> and/or command-line arguments
# =====================================================================================

DEFAULTS = {
    "thresholds": {
        "ll_screen_fraction": 0.10,     # flag LL below this fraction of the file median
        "ll_min_ft": None,              # optional absolute minimum LL (ft); None = not used
        "ll_max_ft": None,              # optional absolute maximum LL (ft), e.g. 20000 for 15k+ ft pods
        "stage_count_min": 15,          # stages = LL / (clusters x cluster spacing)
        "stage_count_max": 120,         # raise for very long laterals or tight stage spacing
        "spe_min_stage_spacing_ft": 100,  # single-point-entry stage spacing below this is flagged
    },
    "settings": {
        "pending_design_blocks_import": True,
        "pad_name_pattern": "{area} {pad} ({rig})",
        "start_date_source": "frac_start",        # or "completions_start"
        "start_date_utc_offset": "-06:00",
        "stage_fluid_mode": "Loading",
        "stage_sand_fluid_unit": "Length",
        "stage_spacing_unit": "Cluster",
        "date_order": "MDY",                      # how numeric text dates such as 03/04/2025 are read: MDY or DMY
        "schedule_glob": "*Schedule*.xlsx",
        "default_folder": os.path.join(os.path.expanduser("~"), "Downloads", "Prepad"),   # the user's own Downloads\Prepad
        "output_subfolder": "",                   # "" = write outputs next to the schedule; e.g. "output_{stamp}"
    },
    "bench_aliases": {"WolfCamp A Lower": "WCA Lower"},
    # Each rule: {"match": {<field>: <value | [values] | "*">, ...}, "value": "<PrePad name>"}.
    # Fields: rig, area, pad_name, region, bench, completion_design, casing, plug_type, frac_provider.
    # Empty "match" = default rule. Rules with an empty "value" are ignored (useful in templates).
    "asset_mapping": {
        "pumping_plan": [],          # Well Design: Pumping Plan            (per well)
        "casing_design": [],         # Well Design: Casing Design           (per well; default = casing text)
        "subsurface_equipment": [],  # Stage Design: Subsurface Equipment   (per well; default = plug type)
        "frac_spread": [],           # Pad: Frac Spread                     (per pad)
        "wireline_equipment": [],    # Pad: Wireline Equipment              (per pad)
        "launcher_equipment": [],    # Pad: Launcher Equipment              (per pad)
        "well_prioritization": [],   # Pad: Which Wells should be prioritized (per pad)
        "prioritization_mode": [],   # Pad: Priorization forced or soft?    (per pad)
    },
}
S = {}   # active configuration, set in main() or by the app

# Guidance shown in the app's Configuration tab and written into config templates.
CONFIG_HELP = {
    "thresholds": {
        "ll_screen_fraction": "Flag a lateral length below this fraction of the file's median LL (0.10 = 10%). Catches values "
                              "entered in thousands of feet. Screening value, not a design limit.",
        "ll_min_ft": "Optional absolute minimum lateral length in ft. Leave off to rely on the median screen.",
        "ll_max_ft": "Optional absolute maximum lateral length in ft, e.g. 20000 for long-lateral pods.",
        "stage_count_min": "Minimum plausible stages per well. Stages = LL / (clusters per stage x cluster spacing).",
        "stage_count_max": "Maximum plausible stages per well. Raise for 15,000 ft+ laterals or tight stage spacing.",
        "spe_min_stage_spacing_ft": "Single-point-entry (1 entry per stage) spacing below this is treated as a misplaced "
                                    "decimal (e.g. 25.0 entered for 250 ft).",
    },
    "settings": {
        "pending_design_blocks_import": "'Pending Review' completion designs are not final. On = ERROR (well not imported); "
                                        "off = WARNING (imported, reported).",
        "pad_name_pattern": "PrePad pad Name. Fields: {area} {pad} {rig} {region}. The rig is included because "
                            "Area + Pad Name repeats across rigs.",
        "start_date_source": "Which schedule date becomes the PrePad Pad Start Date.",
        "start_date_utc_offset": "UTC offset written in Start Date (template example uses -06:00). NM is Mountain "
                                 "(-07:00/-06:00), TX Reeves/Loving is Central (-06:00/-05:00).",
        "stage_fluid_mode": "PrePad Stage Design 'Fluid Loading Value or Ratio'. The schedule gives loadings.",
        "stage_sand_fluid_unit": "PrePad 'Sand and Fluid Unit'. The schedule's intensities are per foot (Length).",
        "stage_spacing_unit": "PrePad 'Spacing Unit'. The schedule gives cluster spacing.",
        "date_order": "How numeric text dates such as 03/04/2025 are read. If the order is impossible "
                      "(e.g. 27/04/2025) the other order is used.",
        "schedule_glob": "File name pattern used to find the schedule in a folder.",
        "default_folder": "Folder the file browser opens in, and where uploaded schedules are saved.",
        "output_subfolder": "Blank = outputs are saved in the same folder as the schedule. Use e.g. 'output_{stamp}' "
                            "for one subfolder per run.",
    },
    "bench_aliases": "Bench naming convention: schedule value -> standard name (matched ignoring case).",
    "asset_mapping": "Rules that fill PrePad-only fields. First matching rule wins; an empty match is the default rule; "
                     "'*' matches any non-blank value; several values separated by ';' match any of them. "
                     "Rules with an empty value are ignored.",
}

DEFAULT_INPUT = DEFAULTS["settings"]["default_folder"]
TEMPLATE_GLOBS = {"Stage Design": "*Stage_Design*Template*.xlsx", "Well Design": "*Well_Design*Template*.xlsx",
                  "Pad": "*Pad*Template*.xlsx"}

# Customer column headers -> internal field names. Add aliases if the customer renames a column.
SOURCE_COLUMNS = {
    "area": ["Area"], "pad_name": ["Pad Name"], "region": ["Region"], "pad_well_count": ["Pad Well Count"],
    "surface_location": ["Surface Location"], "api": ["Well API"], "spud_date": ["Drilling Spud Date"],
    "rig_release": ["Rig Release"], "drilling_days": ["Drilling Days (Spud-RR)"],
    "completions_start": ["Completions Start"], "frac_start": ["Frac Start"], "tvd": ["TVD (ft)"], "md": ["MD (ft)"],
    "ll": ["LL (ft)"], "casing": ["Production Casing Design"], "completion_design": ["Completion Design"],
    "bench": ["Targetted Bench", "Targeted Bench"], "frac_gradient": ["Fracture Gradient (psi/ft)"],
    "proppant_intensity": ["Proppant Intensity (lbs/ft)"], "water_intensity": ["Est. Water Intensity (bbl/ft)"],
    "cluster_spacing": ["Cluster Spacing (ft)"], "clusters_per_stage": ["Cluster per Stage", "Clusters per Stage"],
    "shots_per_cluster": ["Shots per Cluster"], "entry_hole_diameter": ["Entry Hole Diameter (in)"],
    "plug_type": ["Plug type", "Plug Type"], "max_rate": ["Max Flow Rate (BPM)"], "max_pressure": ["Max Pressure (psi)"],
    "frac_provider": ["Frac Provider"],
}
PAD_FIELDS = ["area", "pad_name", "region", "pad_well_count", "surface_location", "completions_start", "frac_start"]
DATE_FIELDS = ["spud_date", "rig_release", "completions_start", "frac_start"]
NUMBER_FIELDS = ["pad_well_count", "drilling_days", "tvd", "md", "ll", "frac_gradient", "proppant_intensity",
                 "water_intensity", "cluster_spacing", "clusters_per_stage", "shots_per_cluster",
                 "entry_hole_diameter", "max_rate", "max_pressure"]
MATCH_FIELDS = ["rig", "area", "pad_name", "region", "bench", "completion_design", "casing", "plug_type", "frac_provider"]

# Check catalogue: ID -> (level, scope, description). Descriptions may use threshold placeholders.
CHECK_DEFS = {
    "W01": ("ERROR", "well", "Well API missing"),
    "W02": ("ERROR", "well", "Duplicate well API (same API on more than one well)"),
    "W03": ("WARNING", "well", "API not in NN-NNN-NNNNN format"),
    "W04": ("WARNING", "well", "API state code does not match Region (possible anonymised data)"),
    "W10": ("ERROR", "well", "Lateral length missing"),
    "W11": ("ERROR", "well", "Lateral length implausible (SCREEN: < {ll_pct:g}% of file median{ll_abs})"),
    "W12": ("ERROR", "well", "MD less than TVD"),
    "W13": ("WARNING", "well", "MD hard-coded where other rows use a formula"),
    "W20": ("{pending_level}", "well", "Completion design is 'Pending Review' (not final)"),
    "W21": ("ERROR", "well", "Stage design input missing (clusters, cluster spacing, proppant or water intensity)"),
    "W22": ("ERROR", "well", "Plug type missing on a plug-and-perf design"),
    "W23": ("WARNING", "well", "Shots per cluster or entry hole diameter missing"),
    "W24": ("ERROR", "well", "Design label does not match clusters x shots"),
    "W25": ("ERROR", "well", "Cluster spacing - entry error: decimal misplaced on single-point-entry spacing "
                             "(SCREEN: < {spe_min:g} ft)"),
    "W26": ("ERROR", "well", "Value differs from the other wells of the same pad and bench (suspected entry error)"),
    "W27": ("WARNING", "well", "Text normalised (extra spaces / non-standard casing text)"),
    "W28": ("ERROR", "well", "Targeted bench missing"),
    "W29": ("ERROR", "well", "Casing design missing"),
    "W30": ("WARNING", "well", "Rig release date missing"),
    "W31": ("WARNING", "well", "Rig release before spud date"),
    "W32": ("WARNING", "well", "Fracture gradient - entry missing (value suggested from offset wells, to be confirmed)"),
    "W33": ("WARNING", "well", "Number stored as text"),
    "W34": ("ERROR", "well", "Copy and paste error: design values match the neighbouring pad, not this pad"),
    "W35": ("ERROR", "well", "Fill-out error: entry missing where every other well on the pad has the same value (import field)"),
    "W36": ("WARNING", "well", "Fill-out error: entry missing where every other well on the pad has the same value (not imported)"),
    "W37": ("ERROR", "well", "Stage count fails sanity check (SCREEN: outside {st_min}-{st_max} stages)"),
    "W38": ("WARNING", "well", "Bench name standardised to the naming convention"),
    "W39": ("WARNING", "well", "Date could not be read"),
    "P01": ("ERROR", "pad", "Pad Well Count differs from the number of well rows"),
    "P02": ("ERROR", "pad", "Pad contains wells that are not ready (PrePad imports whole pads)"),
    "P03": ("ERROR", "pad", "Well order cannot be reproduced by a PrePad distribution option"),
    "P04": ("ERROR", "pad", "More than 3 (bench, well design) combinations; template allows 3"),
    "P05": ("ERROR", "pad", "Frac/completions start date missing or unreadable (needed for Pad Start Date)"),
    "P06": ("WARNING", "pad", "Area + pad name also used under another rig (rig added to PrePad name)"),
    "P07": ("WARNING", "pad", "Surface Location is not a coordinate (placeholder or identifier)"),
    "P08": ("WARNING", "pad", "Frac start is before today; schedule does not say if it is actual or planned"),
    "P09": ("WARNING", "pad", "Single well design on pad: distribution option left blank"),
    "P10": ("WARNING", "pad", "Frac start offset from completions start differs from the usual offset"),
    "P11": ("WARNING", "pad", "Asset mapping gives different values for wells on the same pad; field left blank"),
}
CHECKS = {}  # built from CHECK_DEFS + active thresholds in build_checks()

LIKELY_CAUSE = {
    "W01": "Missing entry", "W02": "Duplicate identifier", "W03": "Entry error", "W04": "Anonymised or wrong identifier",
    "W10": "Missing entry", "W11": "Unit error (thousands of feet?)", "W12": "Entry error", "W13": "Formula overwritten",
    "W20": "Design not final", "W21": "Missing entry", "W22": "Missing entry", "W23": "Missing entry",
    "W24": "Label and values disagree", "W25": "Cluster spacing - entry error (decimal)",
    "W26": "Entry error (odd value within pad)", "W27": "Formatting", "W28": "Missing entry", "W29": "Missing entry",
    "W30": "Not yet planned?", "W31": "Entry error", "W32": "Entry missing", "W33": "Formatting",
    "W34": "Copy and paste error", "W35": "Fill-out error (entry missing)", "W36": "Fill-out error (entry missing)",
    "W37": "Stage count sanity check", "W38": "Naming convention", "W39": "Unreadable date",
    "P01": "Rows missing or extra", "P02": "Wells on pad not ready", "P03": "Well order / design assignment",
    "P04": "Too many designs", "P05": "Missing entry", "P06": "Generic pad name", "P07": "Placeholder text",
    "P08": "Actual vs planned unknown", "P09": "PrePad option undefined", "P10": "Manual override",
    "P11": "Asset mapping conflict",
}
COPY_FIELDS = ["completion_design", "cluster_spacing", "clusters_per_stage", "shots_per_cluster",
               "entry_hole_diameter", "plug_type", "proppant_intensity", "water_intensity"]
FILL_DOWN_FIELDS = {"completion_design": True, "cluster_spacing": True, "clusters_per_stage": True,
                    "shots_per_cluster": False, "entry_hole_diameter": False, "plug_type": True,
                    "proppant_intensity": True, "water_intensity": True, "casing": True, "ll": True,
                    "max_rate": False, "max_pressure": False, "frac_provider": False}

# Which PrePad template an ERROR blocks. Stage and Well Designs are judged well by well; the Pad import rolls them up:
# a pad is written only when every well on it is ready for all three templates and the pad itself has no error.
TEMPLATES = ("Stage Design", "Well Design", "Pad")
SD_FIELDS = set(COPY_FIELDS)
WD_FIELDS = {"ll", "casing", "md", "tvd"}
CHECK_TEMPLATE = {"W01": "Pad", "W02": "Pad", "W10": "Well Design", "W11": "Well Design", "W12": "Well Design",
                  "W20": "Stage Design", "W21": "Stage Design", "W22": "Stage Design", "W24": "Stage Design",
                  "W25": "Stage Design", "W28": "Pad", "W29": "Well Design", "W34": "Stage Design", "W37": "Well Design"}


def issue_template(check, field=None):
    """Template an issue blocks: fixed per check, by field for the value checks (W26, W35 ...), Pad for pad checks."""
    if check in CHECK_TEMPLATE:
        return CHECK_TEMPLATE[check]
    if check.startswith("P"):
        return "Pad"
    if field in SD_FIELDS:
        return "Stage Design"
    if field in WD_FIELDS:
        return "Well Design"
    return "Pad"


SD_HDR = ["Name", "Description", "Fluid Loading Value or Ratio", "Sand and Fluid Unit", "Spacing Unit",
          "Subsurface Equipment", "Clusters Per Stage", "Spacing", "Avg Fluid Loading", "Sand Loading",
          "Sand to Water Ratio", "Minimum Flow Rate Per Cluster", "Plug to First Cluster", "Last Cluster to Plug"]
WD_HDR = ["Name", "Description", "Target Lateral Length", "MD Above LP to Top Perf", "Stage Design", "Pumping Plan", "Casing Design"]
PAD_HDR = ["Name", "Description", "Region", "Subarea", "Start Date", "Frac Spread", "Wireline Equipment", "Launcher Equipment",
           "Which Wells should be prioritized", "Priorization forced or soft?", "Number of Wells",
           "How should Well Designs be distributed amongst wells?", "Type Curve Region 1", "Well Design 1",
           "Type Curve Region 2", "Well Design 2", "Type Curve Region 3", "Well Design 3"]
# PrePad fields filled by asset_mapping (template, column, mapping key)
ASSET_FIELDS = [("Well Design", "Pumping Plan", "pumping_plan"), ("Well Design", "Casing Design", "casing_design"),
                ("Stage Design", "Subsurface Equipment", "subsurface_equipment"), ("Pad", "Frac Spread", "frac_spread"),
                ("Pad", "Wireline Equipment", "wireline_equipment"), ("Pad", "Launcher Equipment", "launcher_equipment"),
                ("Pad", "Which Wells should be prioritized", "well_prioritization"),
                ("Pad", "Priorization forced or soft?", "prioritization_mode")]
# PrePad fields the schedule cannot fill at all
NO_SOURCE_FIELDS = [
    ("Stage Design", "Minimum Flow Rate Per Cluster", "Schedule only gives a MAX flow rate", "Client: design rate per cluster"),
    ("Stage Design", "Plug to First Cluster", "No source column", "Client: perforation design"),
    ("Stage Design", "Last Cluster to Plug", "No source column", "Client: perforation design"),
    ("Stage Design", "Sand to Water Ratio", "Not written: loadings are used instead (Fluid Loading = Loading)", "Confirm with PrePad if required"),
    ("Well Design", "MD Above LP to Top Perf", "No landing-point MD in schedule (MD column is an estimate)", "Client: well plan / landing point MD"),
]
DISTRIBUTION_OPTIONS = {2: "Odd-Even (2 Well Designs)", 3: "Wine Rack (3 Well Designs)"}
API_RE = re.compile(r"^\d{2}-\d{3}-\d{5}$")
STATE_CODE = {"NM": "30", "TX": "42", "CO": "05", "ND": "33", "OK": "35", "WY": "49", "LA": "17", "UT": "43"}
EXCEL_EPOCH = dt.datetime(1899, 12, 30)


# =====================================================================================
# 0. CONFIGURATION LOADING
# =====================================================================================

def deep_merge(base, extra, path=""):
    """Merge extra into base; unknown keys are an error (catches typos in the config file)."""
    out = copymod.deepcopy(base)
    for k, v in (extra or {}).items():
        if k.startswith("_"):            # "_comment" keys are allowed in the JSON file
            continue
        if k not in out:
            sys.exit(f"Config error: unknown key '{path}{k}'. Allowed: {', '.join(out)}")
        if isinstance(out[k], dict) and isinstance(v, dict) and k not in ("bench_aliases",):
            out[k] = deep_merge(out[k], v, f"{path}{k}.")
        else:
            out[k] = v
    return out


class ConfigError(SystemExit):
    pass


def finalize_settings(cfg):
    """Validate a merged configuration and add derived keys. Raises ConfigError (a SystemExit) with a readable message."""
    t, st = cfg["thresholds"], cfg["settings"]
    for k in ("ll_screen_fraction", "stage_count_min", "stage_count_max", "spe_min_stage_spacing_ft"):
        if not isinstance(t[k], (int, float)) or t[k] < 0:
            raise ConfigError(f"Config error: thresholds.{k} must be a positive number (got {t[k]!r})")
    for k in ("ll_min_ft", "ll_max_ft"):
        if t[k] is not None and (not isinstance(t[k], (int, float)) or t[k] <= 0):
            raise ConfigError(f"Config error: thresholds.{k} must be blank (null) or a positive number")
    if t["stage_count_min"] >= t["stage_count_max"]:
        raise ConfigError("Config error: stage_count_min must be below stage_count_max")
    if st["date_order"] not in ("MDY", "DMY"):
        raise ConfigError("Config error: date_order must be MDY or DMY")
    if st["start_date_source"] not in ("frac_start", "completions_start"):
        raise ConfigError("Config error: start_date_source must be frac_start or completions_start")
    try:
        st["pad_name_pattern"].format(area="A", pad="P", rig="R", region="X")
    except (KeyError, IndexError, ValueError) as e:
        raise ConfigError(f"Config error: pad_name_pattern '{st['pad_name_pattern']}' uses an unknown field {e}")
    for key, rules in cfg["asset_mapping"].items():
        if not isinstance(rules, list):
            raise ConfigError(f"Config error: asset_mapping.{key} must be a list of rules")
        for n, rule in enumerate(rules, start=1):
            bad = [f for f in (rule.get("match") or {}) if f not in MATCH_FIELDS]
            if bad:
                raise ConfigError(f"Config error: asset_mapping.{key} rule {n} uses unknown field(s) {bad}. Allowed: {MATCH_FIELDS}")
    cfg["bench_aliases_lc"] = {str(k).lower(): v for k, v in cfg["bench_aliases"].items()}
    return cfg


def settings_from_dict(user_cfg):
    """Configuration from a dict (e.g. edited in the app) merged over DEFAULTS and validated."""
    try:
        cfg = deep_merge(DEFAULTS, user_cfg or {})
    except SystemExit as e:
        raise ConfigError(str(e))
    return finalize_settings(cfg)


def activate(cfg):
    """Make cfg the active configuration for the engine (module-level S and CHECKS)."""
    S.clear()
    S.update(cfg)
    build_checks()


def load_settings(args):
    user = {}
    if args.config:
        try:
            with open(args.config, encoding="utf-8") as f:
                user = json.load(f)
        except json.JSONDecodeError as e:
            sys.exit(f"Config file {args.config} is not valid JSON: {e}")
    cfg = settings_from_dict(user)
    t, st = cfg["thresholds"], cfg["settings"]
    for arg, key in (("ll_screen_fraction", "ll_screen_fraction"), ("ll_min_ft", "ll_min_ft"), ("ll_max_ft", "ll_max_ft"),
                     ("stage_min", "stage_count_min"), ("stage_max", "stage_count_max"),
                     ("spe_min_spacing", "spe_min_stage_spacing_ft")):
        if getattr(args, arg) is not None:
            t[key] = getattr(args, arg)
    if args.pending_design:
        st["pending_design_blocks_import"] = args.pending_design == "error"
    if args.date_order:
        st["date_order"] = args.date_order
    return finalize_settings(cfg)


def build_checks():
    t = S["thresholds"]
    ll_abs = "".join([f"; < {t['ll_min_ft']:g} ft" if t["ll_min_ft"] else "",
                      f"; > {t['ll_max_ft']:g} ft" if t["ll_max_ft"] else ""])
    fmt_args = {"ll_pct": t["ll_screen_fraction"] * 100, "ll_abs": ll_abs, "spe_min": t["spe_min_stage_spacing_ft"],
                "st_min": t["stage_count_min"], "st_max": t["stage_count_max"]}
    pending = "ERROR" if S["settings"]["pending_design_blocks_import"] else "WARNING"
    CHECKS.clear()
    for k, (lvl, scope, desc) in CHECK_DEFS.items():
        CHECKS[k] = (lvl.replace("{pending_level}", pending), scope, desc.format(**fmt_args))


# =====================================================================================
# 1. READ
# =====================================================================================

def find_inputs(path, schedule_glob, template_dirs=()):
    """Return (schedule, {template: path or None}). Templates are looked for next to the schedule first,
    then in template_dirs (e.g. the app's bundled templates folder)."""
    if os.path.isfile(path):
        folder, schedule = os.path.dirname(path) or ".", path
    else:
        folder = path
        hits = [f for f in glob.glob(os.path.join(folder, schedule_glob)) if not os.path.basename(f).startswith("~$")
                and "_QC_Client_Review_" not in os.path.basename(f)]
        if not hits:
            sys.exit(f"No customer schedule matching {schedule_glob} found in {folder}")
        hits.sort(key=os.path.getmtime, reverse=True)
        if len(hits) > 1:
            print(f"Several schedules found; using the newest: {os.path.basename(hits[0])}")
        schedule = hits[0]
    templates = {}
    for name, pat in TEMPLATE_GLOBS.items():
        templates[name] = None
        for d in [folder] + list(template_dirs):
            found = [f for f in glob.glob(os.path.join(d, pat))
                     if not os.path.basename(f).startswith("~$") and (name != "Pad" or "Design" not in os.path.basename(f))]
            if found:
                templates[name] = found[0]
                break
    return schedule, templates


def to_number(v):
    """Return (number, stored_as_text)."""
    if v is None or isinstance(v, bool):
        return None, False
    if isinstance(v, (int, float)):
        return v, False
    s = str(v).replace(",", "").strip()
    if s == "":
        return None, False
    try:
        return float(s), True
    except ValueError:
        return None, True


MONTHS = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}
DATE_RES = [
    (re.compile(r"^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})(?:[T ].*)?$"), "ymd"),       # 2025-04-27, 2025/04/27 12:00
    (re.compile(r"^(\d{4})(\d{2})(\d{2})$"), "ymd"),                                 # 20250427
    (re.compile(r"^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})(?:\s.*)?$"), "numeric"),   # 04/27/2025 (order from settings)
    (re.compile(r"^(\d{1,2})[-/ ]([A-Za-z]{3,9})\.?[-/ ,]+(\d{2,4})$"), "d_mon_y"),  # 27-Apr-25, 27 April 2025
    (re.compile(r"^([A-Za-z]{3,9})\.?[-/ ](\d{1,2})(?:st|nd|rd|th)?,?[-/ ]+(\d{2,4})$"), "mon_d_y"),  # Apr 27, 2025
]


def _year(y):
    y = int(y)
    return y + (2000 if y < 70 else 1900) if y < 100 else y


def to_date(v):
    """Return (date, how) with how in: native, serial, text, unreadable, None (blank).
    Excel serial numbers and common text formats are converted silently; only unreadable values are flagged."""
    if v is None or (isinstance(v, str) and not v.strip()):
        return None, None
    if isinstance(v, dt.datetime):
        return v.date(), "native"
    if isinstance(v, dt.date):
        return v, "native"
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        if 20000 <= v <= 80000:                                  # 1954-10-03 .. 2119-01-10
            return (EXCEL_EPOCH + dt.timedelta(days=float(v))).date(), "serial"
        return None, "unreadable"
    s = str(v).strip()
    if re.fullmatch(r"\d{5}(\.\d+)?", s) and 20000 <= float(s) <= 80000:  # serial stored as text
        return (EXCEL_EPOCH + dt.timedelta(days=float(s))).date(), "serial"
    for rx, kind in DATE_RES:
        m = rx.match(s)
        if not m:
            continue
        try:
            a, b, c = m.groups()
            if kind == "ymd":
                y, mo, d = int(a), int(b), int(c)
            elif kind == "numeric":
                mo, d = (int(a), int(b)) if S["settings"]["date_order"] == "MDY" else (int(b), int(a))
                if mo > 12 and d <= 12:      # configured order impossible (e.g. 27/04/2025): the other order is unambiguous
                    mo, d = d, mo
                y = _year(c)
            elif kind == "d_mon_y":
                d, mo, y = int(a), MONTHS.get(b[:3].lower()), _year(c)
            else:
                mo, d, y = MONTHS.get(a[:3].lower()), int(b), _year(c)
            if mo is None:
                continue
            return dt.date(y, mo, d), "text"
        except ValueError:
            continue
    return None, "unreadable"


def clean_text(v):
    if v is None:
        return None
    s = re.sub(r"\s+", " ", str(v)).strip()
    return s or None


def canonical_casing(v):
    if v is None:
        return None
    nums = re.findall(r"(\d+(?:\.\d*)?)\s*\"", str(v))
    return " x ".join(f'{float(n):.1f}"' for n in nums) if nums else clean_text(v)


def read_schedule(path, overrides=None):
    """Flatten the schedule into one dict per well. Pad-level values are carried down the pad block; rig label
    rows (only the Area column filled) set the rig for the pads below them. overrides = {cell: value} accepted
    corrections, applied in memory after reading (the file is not changed)."""
    overrides = overrides or {}
    wb_values = load_workbook(path, data_only=True)
    wb_formulas = load_workbook(path, data_only=False)
    ws = next(s for s in wb_values.worksheets if s.sheet_state == "visible")
    wf = wb_formulas[ws.title]

    wanted = {h.lower(): key for key, names in SOURCE_COLUMNS.items() for h in names}
    best_row, best_hits = None, 0
    for r in range(1, min(40, ws.max_row) + 1):
        hits = sum(1 for c in ws[r] if c.value and clean_text(c.value).lower() in wanted)
        if hits > best_hits:
            best_row, best_hits = r, hits
    if not best_row or best_hits < len(SOURCE_COLUMNS) // 2:
        sys.exit("Could not find the header row - check the column names in SOURCE_COLUMNS.")
    col = {}
    for c in ws[best_row]:
        key = wanted.get(clean_text(c.value).lower()) if c.value else None
        if key and key not in col:
            col[key] = c.column
    letters = {k: get_column_letter(c) for k, c in col.items()}
    missing_cols = [k for k in SOURCE_COLUMNS if k not in col]
    date_stats = Counter()

    wells, rig, pad = [], None, None
    for r in range(best_row + 1, ws.max_row + 1):
        raw = {k: ws.cell(r, c).value for k, c in col.items()}
        filled = [k for k, v in raw.items() if v not in (None, "")]
        if not filled:
            continue
        if filled == ["area"]:
            rig, pad = clean_text(raw["area"]), None
            continue
        if raw.get("pad_name"):
            pad = {"row": r, "rig": rig, **{k: raw.get(k) for k in PAD_FIELDS}}
        if not any(raw.get(k) not in (None, "") for k in col if k not in PAD_FIELDS):
            continue
        w = {"row": r, "rig": rig, "pad_row": pad["row"] if pad else None, "issues": [], "text_numbers": [],
             "bad_dates": [], "col": letters, "overrides": []}
        for k in SOURCE_COLUMNS:
            v = raw.get(k)
            if v is None and k in PAD_FIELDS and pad:
                v = pad.get(k)
            if k in NUMBER_FIELDS:
                v, as_text = to_number(v)
                if as_text and raw.get(k) is not None:
                    w["text_numbers"].append(k)
            elif k in DATE_FIELDS:
                v, how = to_date(v)
                if how:
                    date_stats[how] += 1 if raw.get(k) is not None else 0
                if how == "unreadable" and raw.get(k) is not None:
                    w["bad_dates"].append((k, raw.get(k)))
            elif k != "casing":
                v = clean_text(v)
            w[k] = v
        w["bench_raw"] = w["bench"]
        if w["bench"] and w["bench"].lower() in S["bench_aliases_lc"]:
            w["bench"] = S["bench_aliases_lc"][w["bench"].lower()]
        w["casing_raw"] = raw.get("casing")
        w["casing"] = canonical_casing(w["casing"])
        w["design_raw"] = raw.get("completion_design")
        w["md_is_formula"] = str(wf.cell(r, col["md"]).value).startswith("=") if "md" in col else None
        w["frac_is_formula"] = str(wf.cell(pad["row"], col["frac_start"]).value).startswith("=") \
            if pad and "frac_start" in col else None
        # accepted corrections (in memory only)
        for k, letter in letters.items():
            addr = f"{letter}{r}"
            if addr in overrides:
                new = overrides[addr]
                if isinstance(new, str) and k in NUMBER_FIELDS + DATE_FIELDS:
                    new = parse_user_value(k, new)[0]
                w["overrides"].append({"cell": addr, "field": k, "original": w[k], "new": new})
                w[k] = canonical_casing(new) if k == "casing" else new
                if k == "bench" and isinstance(new, str) and new.lower() in S["bench_aliases_lc"]:
                    w["bench"] = S["bench_aliases_lc"][new.lower()]
        wells.append(w)
    return {"sheet": ws.title, "header_row": best_row, "wells": wells, "missing_cols": missing_cols,
            "col": letters, "date_stats": date_stats}


# =====================================================================================
# 2. CHECK
# =====================================================================================

def flag(obj, check_id, detail, field=None, cells=None, suggest=None):
    """Record an issue. cells = cells highlighted in the client copy (default: the field's cell);
    suggest = [(cell, value, basis)] proposed corrections - applied only if an engineer accepts them."""
    level, scope, desc = CHECKS[check_id]
    if cells is None and field and "col" in obj:
        cells = [cell(obj, field)]
    obj["issues"].append({"check": check_id, "level": level, "description": desc, "detail": detail, "field": field,
                          "cells": cells or [], "suggest": suggest or [], "template": issue_template(check_id, field)})


def cell(w, field):
    return f"{w['col'].get(field, '?')}{w['row']}"


def pad_key(w):
    return (w["rig"], w["area"], w["pad_name"], w["pad_row"])


def fmt_blank(v):
    return "blank" if v is None else (f"{v:g}" if isinstance(v, float) else str(v))


def check_wells(wells):
    t = S["thresholds"]
    apis = Counter(w["api"] for w in wells if w["api"])
    lls = [w["ll"] for w in wells if isinstance(w["ll"], (int, float))]
    ll_median = statistics.median(lls) if lls else None
    md_formula_rows = sum(1 for w in wells if w["md_is_formula"])

    for w in wells:
        design = w["completion_design"] or ""
        is_spe = design.upper().startswith("SPE")
        if not w["api"]:
            flag(w, "W01", f"{cell(w, 'api')} blank", "api")
        else:
            if apis[w["api"]] > 1:
                others = [str(x["row"]) for x in wells if x["api"] == w["api"] and x is not w]
                flag(w, "W02", f"{cell(w, 'api')} {w['api']} also on row(s) {', '.join(others)}", "api")
            if not API_RE.match(w["api"]):
                flag(w, "W03", f"{cell(w, 'api')} '{w['api']}'", "api")
            elif w["region"] in STATE_CODE and w["api"][:2] != STATE_CODE[w["region"]]:
                flag(w, "W04", f"{cell(w, 'api')} state code {w['api'][:2]} vs Region {w['region']}", "api")
        ll = w["ll"]
        if ll is None:
            flag(w, "W10", f"{cell(w, 'll')} blank", "ll")
        else:
            why = []
            if ll_median and ll < t["ll_screen_fraction"] * ll_median:
                why.append(f"file median {ll_median:,.0f} ft")
            if t["ll_min_ft"] and ll < t["ll_min_ft"]:
                why.append(f"minimum {t['ll_min_ft']:,.0f} ft")
            if t["ll_max_ft"] and ll > t["ll_max_ft"]:
                why.append(f"maximum {t['ll_max_ft']:,.0f} ft")
            if why:
                sug = [(cell(w, "ll"), ll * 1000, "lateral length appears entered in thousands of feet")] if ll < 100 else []
                flag(w, "W11", f"{cell(w, 'll')} = {ll:g} ft entered vs {', '.join(why)}"
                               + (". Appears entered in thousands of feet" if sug else ""), "ll", suggest=sug)
        if isinstance(w["md"], (int, float)) and isinstance(w["tvd"], (int, float)) and w["md"] < w["tvd"]:
            sug = []
            if md_formula_rows > len(wells) / 2 and ll is not None:
                sug = [(cell(w, "md"), w["tvd"] + ll + 400,
                        f"TVD + LL + 400, the formula used on the other rows (={cell(w, 'tvd')}+{cell(w, 'll')}+400)")]
            flag(w, "W12", f"{cell(w, 'md')} MD {w['md']:g} ft < TVD {w['tvd']:g} ft", "md", suggest=sug)
        if w["md_is_formula"] is False and md_formula_rows > len(wells) / 2 and not any(o["field"] == "md" for o in w["overrides"]):
            flag(w, "W13", f"{cell(w, 'md')} hard-coded {fmt_blank(w['md'])}", "md")
        if "pending" in design.lower():
            flag(w, "W20", f"{cell(w, 'completion_design')} '{design}'", "completion_design")
        for f in ("clusters_per_stage", "cluster_spacing", "proppant_intensity", "water_intensity"):
            if w[f] is None:
                flag(w, "W21", f"{cell(w, f)} {f.replace('_', ' ')} blank", f)
        if not is_spe and w["plug_type"] is None:
            flag(w, "W22", f"{cell(w, 'plug_type')} blank", "plug_type")
        if not is_spe and (w["shots_per_cluster"] is None or w["entry_hole_diameter"] is None):
            flag(w, "W23", f"{cell(w, 'shots_per_cluster')}/{cell(w, 'entry_hole_diameter')} blank", "shots_per_cluster")
        m = re.search(r"(\d+)\s*x\s*(\d+)", design)
        if m and w["clusters_per_stage"] and w["shots_per_cluster"] and \
                (int(m.group(1)), int(m.group(2))) != (int(w["clusters_per_stage"]), int(w["shots_per_cluster"])):
            flag(w, "W24", f"label {m.group(0)} vs {w['clusters_per_stage']:g} x {w['shots_per_cluster']:g}", "completion_design")
        m = re.search(r"(\d+)\s*-\s*(\d+)\s*cluster", design)
        if m and w["clusters_per_stage"] and not int(m.group(1)) <= w["clusters_per_stage"] <= int(m.group(2)):
            flag(w, "W24", f"label {m.group(0)} vs {w['clusters_per_stage']:g} clusters", "completion_design")
        v = w["cluster_spacing"]
        if is_spe and w["clusters_per_stage"] == 1 and v and v < t["spe_min_stage_spacing_ft"]:
            flag(w, "W25", f"{cell(w, 'cluster_spacing')} = {v:.1f} ft entered; single-point entry treats one point per stage, "
                           f"so this is the stage spacing. Decimal appears misplaced: {v * 10:g} ft intended", "cluster_spacing",
                 suggest=[(cell(w, "cluster_spacing"), v * 10, "decimal misplaced (x10)")])
        if w["casing_raw"] is not None and w["casing"] != w["casing_raw"] and not w["overrides"]:
            flag(w, "W27", f"{cell(w, 'casing')} '{w['casing_raw']}' read as '{w['casing']}'", "casing")
        if w["design_raw"] is not None and design != w["design_raw"] and not any(o["field"] == "completion_design" for o in w["overrides"]):
            flag(w, "W27", f"{cell(w, 'completion_design')} '{w['design_raw']}' read as '{design}'", "completion_design")
        if not w["bench"]:
            flag(w, "W28", f"{cell(w, 'bench')} blank", "bench")
        elif w["bench_raw"] != w["bench"] and not any(o["field"] == "bench" for o in w["overrides"]):
            flag(w, "W38", f"{cell(w, 'bench')} '{w['bench_raw']}' = '{w['bench']}'", "bench",
                 suggest=[(cell(w, "bench"), w["bench"], "bench naming convention")])
        if not w["casing"]:
            flag(w, "W29", f"{cell(w, 'casing')} blank", "casing")
        if w["rig_release"] is None and not any(k == "rig_release" for k, _ in w["bad_dates"]):
            flag(w, "W30", f"{cell(w, 'rig_release')} blank", "rig_release")
        elif w["spud_date"] and w["rig_release"] and w["rig_release"] < w["spud_date"]:
            flag(w, "W31", f"spud {w['spud_date']} / RR {w['rig_release']}", "rig_release")
        for f in w["text_numbers"]:
            flag(w, "W33", f"{cell(w, f)} ({f.replace('_', ' ')})", f)
        for f, raw in w["bad_dates"]:
            flag(w, "W39", f"{cell(w, f)} '{raw}' ({f.replace('_', ' ')})", f)

    # Same pad + same bench should share a design: flag the odd one out (or both if there is no majority).
    design_fields = COPY_FIELDS + ["ll", "casing"]
    groups = defaultdict(list)
    for w in wells:
        groups[(pad_key(w), w["bench"])].append(w)
    for (pk, bench), ws in groups.items():
        if len(ws) < 2:
            continue
        pad_wells = [w for w in wells if pad_key(w) == pk]
        for f in design_fields:
            vals = [(w, w[f]) for w in ws if w[f] is not None]
            counts = Counter(v for _, v in vals)
            if len(counts) < 2:
                continue
            common, n = counts.most_common(1)[0]
            if n >= 2 and n > len(vals) - n:
                odd = [(w, v) for w, v in vals if v != common]
            else:
                pc = Counter(w[f] for w in pad_wells if w[f] is not None).most_common(1)[0]
                odd = [(w, v) for w, v in vals if v != pc[0]] if pc[1] > len(pad_wells) / 2 else vals
            for w, v in odd:
                others = ", ".join(f"row {x['row']}={x[f]}" for x, _ in vals if x is not w)
                maj = Counter(x[f] for x in pad_wells if x is not w and x[f] is not None).most_common(1)
                sug = [(cell(w, f), maj[0][0], f"value used on {maj[0][1]} other well(s) of this pad")] \
                    if maj and maj[0][1] >= 2 and len(odd) == 1 else []
                flag(w, "W26", f"{cell(w, f)} {f.replace('_', ' ')} = {v} vs {others} (bench {bench})", f, suggest=sug)

    find_copy_paste_and_fill_down(wells)
    frac_gradient_suggestions(wells)
    stage_count_check(wells)


def find_copy_paste_and_fill_down(wells):
    """W34 copy and paste: a well odd within its pad (W26) whose whole design matches the pad above or below.
    W35/W36 fill-out error: blank where every other well on the pad has the same value.
    Both replace the generic issue on the same cells so each cell is reported once."""
    order, by_pad = [], defaultdict(list)
    for w in wells:
        if pad_key(w) not in by_pad:
            order.append(pad_key(w))
        by_pad[pad_key(w)].append(w)

    def sig(w):
        return tuple(w[f] for f in COPY_FIELDS)

    for i, pk in enumerate(order):
        ws = by_pad[pk]
        for w in ws:
            if not any(x["check"] == "W26" for x in w["issues"]):
                continue
            own = [sig(x) for x in ws if x is not w]
            for j in (i - 1, i + 1):
                if not 0 <= j < len(order) or sig(w) in own:
                    continue
                nb = by_pad[order[j]]
                if sum(1 for x in nb if sig(x) == sig(w)) >= 2:
                    common = Counter(own).most_common(1)[0][0]
                    diff = [(k, f) for k, f in enumerate(COPY_FIELDS) if w[f] != common[k]]
                    w["issues"] = [x for x in w["issues"] if not (x["check"] == "W26" and x["field"] in COPY_FIELDS)
                                   and not (x["field"] in COPY_FIELDS and x["check"] in ("W20", "W21", "W22", "W23"))]
                    nb_rows = ", ".join(str(x["row"]) for x in nb if sig(x) == sig(w))
                    flag(w, "W34", f"design matches rows {nb_rows} of the {'next' if j > i else 'previous'} pad "
                                   f"({nb[0]['area']} {nb[0]['pad_name']}); differs from its own pad in: "
                         + "; ".join(f"{cell(w, f)} {f.replace('_', ' ')} = {fmt_blank(w[f])} (pad: {fmt_blank(common[k])})"
                                     for k, f in diff),
                         "completion_design", cells=[cell(w, f) for _, f in diff],
                         suggest=[(cell(w, f), common[k], "value used on the other wells of this pad") for k, f in diff])
                    break

    for ws in by_pad.values():
        if len(ws) < 2:
            continue
        for f, imported in FILL_DOWN_FIELDS.items():
            for w in ws:
                if w[f] is not None or (f in COPY_FIELDS and any(x["check"] == "W34" for x in w["issues"])):
                    continue
                others = [x[f] for x in ws if x is not w]
                if others and all(v is not None for v in others) and len(set(others)) == 1:
                    w["issues"] = [x for x in w["issues"] if not (x["field"] == f and x["check"] in ("W21", "W22", "W23", "W26"))]
                    flag(w, "W35" if imported else "W36",
                         f"{cell(w, f)} {f.replace('_', ' ')} blank; other {len(others)} wells on pad = {fmt_blank(others[0])}", f,
                         suggest=[(cell(w, f), others[0], f"value on the other {len(others)} wells of this pad")])


def frac_gradient_suggestions(wells):
    """W32: blank fracture gradient; suggest a value from the nearest offset wells (same pad and bench ->
    same pad -> same rig, area and bench -> same area and bench -> same bench). To be confirmed by the client."""
    tiers = [("same pad and bench", lambda w, x: pad_key(x) == pad_key(w) and x["bench"] == w["bench"]),
             ("same pad", lambda w, x: pad_key(x) == pad_key(w)),
             ("same rig, area and bench", lambda w, x: (x["rig"], x["area"], x["bench"]) == (w["rig"], w["area"], w["bench"])),
             ("same area and bench", lambda w, x: (x["area"], x["bench"]) == (w["area"], w["bench"])),
             ("same bench", lambda w, x: x["bench"] == w["bench"])]
    blank_rows = {w["row"] for w in wells if w["frac_gradient"] is None}
    for i, w in enumerate(wells):
        if w["frac_gradient"] is not None:
            continue
        sug, basis = None, "no offset well with a value found"
        for name, match in tiers:
            offs = sorted((x for x in wells if x is not w and x["frac_gradient"] is not None and match(w, x)),
                          key=lambda x: abs(x["row"] - w["row"]))[:6]
            if offs:
                val, n = Counter(x["frac_gradient"] for x in offs).most_common(1)[0]
                sug, basis = val, f"offset wells ({name}) rows {', '.join(str(x['row']) for x in offs)}: {val:g} psi/ft on {n} of {len(offs)}"
                break
        note = "; blank on every well of this pad" if all(x["frac_gradient"] is None for x in wells if pad_key(x) == pad_key(w)) else ""
        run, k = [], i - 1
        while k >= 0 and wells[k]["row"] in blank_rows and pad_key(wells[k]) != pad_key(w):
            run.append(wells[k])
            k -= 1
        if run and pad_key(wells[i - 1]) != pad_key(w):
            note += (f"; same as the pad above ({run[-1]['area']} {run[-1]['pad_name']}, "
                     f"rows {min(x['row'] for x in run)}-{max(x['row'] for x in run)} also blank)")
        flag(w, "W32", f"{cell(w, 'frac_gradient')} entry missing{note}", "frac_gradient",
             suggest=[(cell(w, "frac_gradient"), sug, basis)] if sug is not None else [])


def suggested(w, field):
    for i in w["issues"]:
        for c, v, _ in i["suggest"]:
            if c == cell(w, field) and isinstance(v, (int, float)):
                return v
    return w[field]


def stage_count_check(wells):
    """Stages = LL / (clusters per stage x cluster spacing); single-point entry = LL / stage spacing."""
    lo, hi = S["thresholds"]["stage_count_min"], S["thresholds"]["stage_count_max"]

    def calc(ll, n, sp):
        return (n * sp, ll / (n * sp)) if ll and n and sp else (None, None)

    for w in wells:
        w["stage_len"], w["stages"] = calc(w["ll"], w["clusters_per_stage"], w["cluster_spacing"])
        w["stage_len_corr"], w["stages_corr"] = calc(suggested(w, "ll"), suggested(w, "clusters_per_stage"),
                                                     suggested(w, "cluster_spacing"))
        if w["stages"] is not None and not lo <= w["stages"] <= hi:
            corr = f"; {w['stages_corr']:.0f} stages with the suggested corrections" \
                if w["stages_corr"] and w["stages_corr"] != w["stages"] else ""
            flag(w, "W37", f"{w['ll']:g} ft / ({w['clusters_per_stage']:g} x {w['cluster_spacing']:g} ft = "
                           f"{w['stage_len']:g} ft per stage) = {w['stages']:.1f} stages as entered{corr}",
                 cells=[cell(w, "ll"), cell(w, "clusters_per_stage"), cell(w, "cluster_spacing")])


def build_pads(wells, today):
    pads = {}
    for w in wells:
        pads.setdefault(pad_key(w), {"wells": [], "issues": []})["wells"].append(w)
    names = Counter((k[1], k[2]) for k in pads)
    offsets = Counter()
    src_key = S["settings"]["start_date_source"]
    for (rig, area, pname, prow), p in pads.items():
        w0 = p["wells"][0]
        p.update({"rig": rig, "area": area, "pad_name": pname, "row": prow, "region": w0["region"],
                  "count": w0["pad_well_count"], "frac_start": w0["frac_start"], "completions_start": w0["completions_start"],
                  "surface_location": w0["surface_location"], "frac_is_formula": w0["frac_is_formula"],
                  "name": S["settings"]["pad_name_pattern"].format(area=area, pad=pname, rig=rig, region=w0["region"])})
        if p["frac_start"] and p["completions_start"]:
            p["offset"] = (p["frac_start"] - p["completions_start"]).days
            offsets[p["offset"]] += 1
    usual = offsets.most_common(1)[0][0] if offsets else None
    for p in pads.values():
        rows = f"rows {p['wells'][0]['row']}-{p['wells'][-1]['row']}"
        c0 = p["wells"][0]["col"]

        def pc(f):
            return [f"{c0.get(f, '?')}{p['row']}"]
        if p["count"] != len(p["wells"]):
            flag(p, "P01", f"Pad Well Count {fmt_blank(p['count'])} vs {len(p['wells'])} well rows ({rows})", cells=pc("pad_well_count"))
        if not p.get(src_key):
            flag(p, "P05", f"{src_key.replace('_', ' ')} blank or unreadable ({rows})", cells=pc(src_key))
        if names[(p["area"], p["pad_name"])] > 1:
            flag(p, "P06", f"'{p['area']} {p['pad_name']}' also used under another rig; PrePad name '{p['name']}'", cells=pc("pad_name"))
        sl = p["surface_location"]
        if sl and not re.search(r"-?\d+\.\d+\s*,\s*-?\d+\.\d+", str(sl)):
            flag(p, "P07", f"Surface Location = '{sl}'", cells=pc("surface_location"))
        if p["frac_start"] and p["frac_start"] < today:
            flag(p, "P08", f"frac start {p['frac_start']}", cells=pc("frac_start"))
        if p.get("offset") is not None and (p["offset"] != usual or p["frac_is_formula"] is False):
            flag(p, "P10", f"frac start = completions start + {p['offset']} days (usual {usual}); "
                           f"{'formula' if p['frac_is_formula'] else 'hard-coded value'}", cells=pc("frac_start"))
    return pads


# =====================================================================================
# 3. ASSET MAPPING (PrePad-only fields)
# =====================================================================================

def _match(rule_value, actual):
    if rule_value == "*":
        return actual not in (None, "")
    vals = rule_value if isinstance(rule_value, list) else [rule_value]
    a = clean_text(actual).lower() if actual is not None else None
    return any((clean_text(str(v)).lower() if v is not None else None) == a for v in vals)


def map_asset(key, w):
    """First rule whose 'match' conditions all hold for well w; returns (value, rule index) or (None, None)."""
    for idx, rule in enumerate(S["asset_mapping"].get(key) or []):
        if not str(rule.get("value") or "").strip():
            continue
        bad = [f for f in (rule.get("match") or {}) if f not in MATCH_FIELDS]
        if bad:
            sys.exit(f"Config error: asset_mapping.{key} rule {idx + 1} uses unknown field(s) {bad}. Allowed: {MATCH_FIELDS}")
        if all(_match(v, w.get(f)) for f, v in (rule.get("match") or {}).items()):
            return rule["value"], idx + 1
    return None, None


def apply_asset_mapping(wells, pads):
    for w in wells:
        w["pumping_plan"], _ = map_asset("pumping_plan", w)
        cd, _ = map_asset("casing_design", w)
        w["casing_design"] = cd or w["casing"]
        se, _ = map_asset("subsurface_equipment", w)
        w["subsurface_equipment"] = se or w["plug_type"]
    for p in pads.values():
        p["assets"] = {}
        for _, column, key in ASSET_FIELDS:
            if key in ("pumping_plan", "casing_design", "subsurface_equipment"):
                continue
            vals = {map_asset(key, w)[0] for w in p["wells"]}
            vals.discard(None)
            if len(vals) == 1:
                p["assets"][column] = vals.pop()
            elif len(vals) > 1:
                flag(p, "P11", f"{column}: {', '.join(sorted(vals))}")


# =====================================================================================
# 4. READINESS PER TEMPLATE, DESIGN LIBRARY AND STATUS
# =====================================================================================

def fmt(v):
    if v is None:
        return "NA"
    return f"{v:g}" if isinstance(v, (int, float)) else str(v)


def well_readiness(wells):
    """Per-well readiness for each template. Well Design needs a clean Stage Design; Pad needs both plus clean pad data."""
    for w in wells:
        blocked = {i["template"] for i in w["issues"] if i["level"] == "ERROR"}
        w["blocked"] = blocked
        w["sd_ok"] = "Stage Design" not in blocked
        w["wd_ok"] = w["sd_ok"] and "Well Design" not in blocked
        w["pad_ok"] = w["wd_ok"] and "Pad" not in blocked


def not_ready_reason(w):
    if not w["sd_ok"]:
        return "stage design"
    if not w["wd_ok"]:
        return "well design"
    return "pad data"


def build_designs(wells, pads):
    """Stage and Well Designs are built well by well from every well whose own design data is clean, whatever the
    state of its pad. Pad slots and the distribution option are worked out only for pads whose wells are all ready."""
    sds, wds = {}, {}
    for w in wells:
        w.pop("sd_name", None)
        w.pop("wd_name", None)
        if not w["sd_ok"]:
            continue
        sd_key = (w["completion_design"], w["cluster_spacing"], w["clusters_per_stage"], w["shots_per_cluster"],
                  w["entry_hole_diameter"], w["subsurface_equipment"], w["proppant_intensity"], w["water_intensity"])
        if sd_key not in sds:
            label = re.sub(r"\s+-\s+", " ", w["completion_design"] or "NoLabel").replace(" clusters", "")
            sds[sd_key] = {"name": f"SD-{len(sds) + 1:03d} {label} {fmt(w['clusters_per_stage'])}cl {fmt(w['cluster_spacing'])}ft "
                                   f"{fmt(w['proppant_intensity'])}ppf {fmt(w['water_intensity'])}bpf", "key": sd_key, "wells": []}
        sds[sd_key]["wells"].append(w)
        w["sd_name"] = sds[sd_key]["name"]
        if not w["wd_ok"]:
            continue
        wd_key = (w["ll"], w["casing_design"], w["pumping_plan"], sds[sd_key]["name"])
        if wd_key not in wds:
            cas = re.sub(r'["\s]', "", w["casing"] or "NA")
            wds[wd_key] = {"name": f"WD-{len(wds) + 1:03d} {fmt(w['ll'])}ft {cas} {sds[sd_key]['name'][:6]}",
                           "key": wd_key, "wells": [], "sd": sds[sd_key]}
        wds[wd_key]["wells"].append(w)
        w["wd_name"] = wds[wd_key]["name"]

    for p in pads.values():
        p["issues"] = [i for i in p["issues"] if i["check"] not in ("P02", "P03", "P04", "P09")]
        p["slots"], p["dist"] = [], None
        bad = [w for w in p["wells"] if not w["pad_ok"]]
        if bad:
            flag(p, "P02", f"{len(bad)} of {len(p['wells'])} wells not ready: "
                 + ", ".join(f"row {w['row']} ({not_ready_reason(w)})" for w in bad))
            continue
        slots, seq = [], []
        for w in p["wells"]:
            slot = (w["bench"], w["wd_name"])
            if slot not in slots:
                slots.append(slot)
            seq.append(slots.index(slot))
        p["slots"] = slots
        k = len(slots)
        if k == 1:
            flag(p, "P09", f"all {len(p['wells'])} wells use {slots[0][1]}")
        elif k > 3:
            flag(p, "P04", f"{k} combinations: " + "; ".join(f"{b}/{n[:6]}" for b, n in slots))
        elif seq == [i % k for i in range(len(seq))]:
            p["dist"] = DISTRIBUTION_OPTIONS[k]
        else:
            flag(p, "P03", f"slot order {[s + 1 for s in seq]} for benches {[w['bench'] for w in p['wells']]}")
    return sds, wds


# Well status = how far the well gets into PrePad.
WELL_STATUSES = ["IMPORTED", "DESIGNS ONLY", "STAGE DESIGN ONLY", "NOT IMPORTED"]
STATUS_TEXT = {"IMPORTED": "Imported: pad, well design and stage design",
               "DESIGNS ONLY": "Well and stage design imported; pad held",
               "STAGE DESIGN ONLY": "Stage design imported; well design and pad held",
               "NOT IMPORTED": "Not imported (stage design errors)"}


def decide_status(wells, pads):
    for p in pads.values():
        p["status"] = "REJECT" if any(i["level"] == "ERROR" for i in p["issues"]) else "IMPORT"
    for w in wells:
        if pads[pad_key(w)]["status"] == "IMPORT":
            w["status"] = "IMPORTED"
        elif w["wd_ok"]:
            w["status"] = "DESIGNS ONLY"
        elif w["sd_ok"]:
            w["status"] = "STAGE DESIGN ONLY"
        else:
            w["status"] = "NOT IMPORTED"


def template_states(w, p):
    """Per-template result for one well, for reports."""
    sd = "Imported" if w["sd_ok"] else "Held - stage design errors"
    wd = "Imported" if w["wd_ok"] else ("Held - stage design not imported" if not w["sd_ok"] else "Held - well design errors")
    if w["status"] == "IMPORTED":
        pad = "Imported"
    elif not w["pad_ok"]:
        pad = "Held - this well is not ready"
    else:
        others = [str(x["row"]) for x in p["wells"] if not x["pad_ok"]]
        pad = (f"Held - other wells not ready (row(s) {', '.join(others)})" if others else "Held - pad-level error")
    return {"Stage Design": sd, "Well Design": wd, "Pad": pad}


def status_counts(res):
    n = Counter(w["status"] for w in res["wells"])
    return {k: n.get(k, 0) for k in WELL_STATUSES}


def analyze(schedule, today, overrides=None):
    """Full analysis from a fresh read. Re-run after corrections are accepted."""
    src = read_schedule(schedule, overrides)
    wells = src["wells"]
    check_wells(wells)
    pads = build_pads(wells, today)
    apply_asset_mapping(wells, pads)
    well_readiness(wells)
    sds, wds = build_designs(wells, pads)
    decide_status(wells, pads)
    return {"src": src, "wells": wells, "pads": pads, "sds": sds, "wds": wds}


# =====================================================================================
# 5. INTERACTIVE BATCH RESOLUTION
# =====================================================================================

def collect_batches(res):
    """Group suggested corrections into batches the engineer can accept together."""
    batches = defaultdict(list)
    for w in res["wells"]:
        for i in w["issues"]:
            for c, v, basis in i["suggest"]:
                field = next((k for k, letter in w["col"].items() if f"{letter}{w['row']}" == c), None)
                if field is None or v is None or v == w.get(field):
                    continue                     # nothing to change (e.g. bench already standardised)
                key = (i["check"], w["row"]) if i["check"] == "W34" else (i["check"], field, str(v))
                batches[key].append({"cell": c, "row": w["row"], "field": field, "original": w.get(field), "new": v,
                                     "check": i["check"], "basis": basis, "pad": f"{w['area']} {w['pad_name']} ({w['rig']})"})
    return sorted(batches.values(), key=lambda b: (b[0]["check"], b[0]["row"]))


CELL_RE = re.compile(r"^\s*([A-Za-z]{1,3}\d+)\s*=\s*(.*?)\s*$")


def parse_user_value(field, v):
    """Convert a value entered by the engineer to the field's type. Returns (value, error or None).
    'blank' clears the cell. Numbers and dates use the same parsing as the schedule reader."""
    if isinstance(v, str) and v.strip().lower() in ("blank", "(blank)", "none"):
        return None, None
    if v is None or (isinstance(v, str) and not v.strip()):
        return None, "no value entered"
    if field in NUMBER_FIELDS:
        n, _ = to_number(v)
        if n is None:
            return None, f"'{v}' is not a number"
        return (int(n) if isinstance(n, float) and n.is_integer() else n), None
    if field in DATE_FIELDS:
        d, how = to_date(v)
        if d is None or how == "unreadable":
            return None, f"'{v}' is not a readable date (use e.g. 2026-04-27)"
        return d, None
    return (canonical_casing(v) if field == "casing" else clean_text(v)), None


def apply_user_change(batch, text):
    """Apply an engineer's own value to a batch of suggested corrections.
    text = one value for every cell of the batch (single-field batches), or 'CELL=value; CELL=value' for chosen cells
    (cells not listed keep the suggested value). Returns (items, errors). Each overridden item keeps the suggestion in
    'suggested' and is marked user_override=True."""
    text = "" if text is None else str(text).strip()
    if not text:
        return [dict(i) for i in batch], []
    by_cell = {i["cell"].upper(): i for i in batch}
    parts = [x for x in text.split(";") if x.strip()]
    pairs = [CELL_RE.match(x) for x in parts]
    if all(pairs):
        wanted = {m.group(1).upper(): m.group(2) for m in pairs}
        unknown = [c for c in wanted if c not in by_cell]
        if unknown:
            return [], [f"{', '.join(unknown)} not in this batch (cells: {', '.join(by_cell)})"]
    elif len({i["field"] for i in batch}) > 1:
        return [], ["this batch changes several fields - enter CELL=value pairs separated by ';' (e.g. "
                    + "; ".join(f"{i['cell']}={fmt_blank(i['new'])}" for i in batch[:2]) + ")"]
    else:
        v, err = parse_user_value(batch[0]["field"], text)
        if err:
            return [], [err]
        wanted = {c: text for c in by_cell}
    items, errors = [], []
    for c, i in by_cell.items():
        if c not in wanted:
            items.append(dict(i))
            continue
        v, err = parse_user_value(i["field"], wanted[c])
        if err:
            errors.append(f"{i['cell']}: {err}")
            continue
        if v == i["new"]:
            items.append(dict(i))
        else:
            items.append({**i, "suggested": i["new"], "new": v, "user_override": True,
                          "basis": f"engineer value (suggested {fmt_blank(i['new'])}: {i['basis']})"})
    return items, errors


def ask(prompt, options):
    while True:
        try:
            a = input(prompt).strip().lower()
        except EOFError:
            print()
            return "q"
        if a in options:
            return a
        print(f"   please answer one of: {', '.join(options)}")


def interactive_session(res, engineer):
    batches = collect_batches(res)
    if not batches:
        print("\nNo suggested corrections to review.")
        return []
    print(f"\n{len(batches)} batches of suggested corrections ({sum(len(b) for b in batches)} cells). "
          "Accepted corrections are applied in memory only and logged; the schedule file is not changed.")
    accepted = []
    stamp = dt.datetime.now().isoformat(timespec="seconds")
    for n, b in enumerate(batches, start=1):
        x = b[0]
        cells = ", ".join(i["cell"] for i in b[:8]) + (f" ... (+{len(b) - 8})" if len(b) > 8 else "")
        print(f"\n[{n}/{len(batches)}] {x['check']} {LIKELY_CAUSE.get(x['check'], '')} - {x['field'].replace('_', ' ')}")
        if x["check"] == "W34":
            print(f"   Row {x['row']} ({x['pad']}): " + "; ".join(f"{i['cell']} {fmt_blank(i['original'])} -> {fmt_blank(i['new'])}" for i in b))
        else:
            print(f"   {len(b)} cell(s): {cells}")
            print(f"   {fmt_blank(x['original'])} -> {fmt_blank(x['new'])}   basis: {x['basis']}")
        a = ask("   [a]ccept all / [r]eview one by one / [e]nter your own value / [s]kip / [q]uit: ", ["a", "r", "e", "s", "q"])
        if a == "q":
            break
        if a == "s":
            continue
        if a == "e":
            while True:
                try:
                    txt = input("   value for all cells (or CELL=value; CELL=value, 'blank' clears, empty = cancel): ")
                except EOFError:
                    txt = ""
                if not txt.strip():
                    break
                items, errs = apply_user_change(b, txt)
                if errs:
                    print("   " + "; ".join(errs))
                    continue
                accepted += [{**i, "engineer": engineer, "accepted_at": stamp} for i in items]
                break
            continue
        for i in b:
            if a == "r":
                yn = ask(f"     {i['cell']} {fmt_blank(i['original'])} -> {fmt_blank(i['new'])} ({i['basis']})  accept? [y/n]: ", ["y", "n"])
                if yn != "y":
                    continue
            accepted.append({**i, "engineer": engineer, "accepted_at": stamp})
    print(f"\n{len(accepted)} correction(s) accepted.")
    return accepted


def load_resolutions(path, schedule):
    """Replay a resolutions file. A correction is skipped if its source cell no longer holds the original value."""
    with open(path, encoding="utf-8") as f:
        items = json.load(f).get("corrections", [])
    ok, skipped = filter_resolutions(items, schedule)
    for s_ in skipped:
        print(f"  skipped {s_['cell']}: source now '{s_['current']}', correction was made against '{s_['original']}'")
    return ok


def filter_resolutions(items, schedule):
    """Split corrections into (still valid, skipped because the source cell changed)."""
    base = read_schedule(schedule)
    current = {f"{w['col'][k]}{w['row']}": w.get(k) for w in base["wells"] for k in w["col"]}
    ok, skipped = [], []
    for i in items:
        cur = current.get(i["cell"])
        if (cur is None and i["original"] is None) or str(cur) == str(i["original"]) or \
                (isinstance(cur, (int, float)) and isinstance(i["original"], (int, float)) and abs(cur - i["original"]) < 1e-9):
            ok.append(i)
        else:
            skipped.append({**i, "current": cur})
    return ok, skipped


# =====================================================================================
# 6. WRITE
# =====================================================================================

def write_import(template, out_path, header, rows):
    if template:
        shutil.copyfile(template, out_path)
        wb = load_workbook(out_path)
        ws = wb.worksheets[0]
        found = [c.value for c in ws[1] if c.value is not None]
        if found != header:
            sys.exit(f"Template {os.path.basename(template)} headers differ from the script:\n{found}\n{header}")
        if ws.max_row > 1:
            ws.delete_rows(2, ws.max_row - 1)
    else:
        wb = Workbook()
        ws = wb.active
        ws.title = "Sheet1"
        ws.append(header)
    for r in rows:
        ws.append([r.get(h) for h in header])
    wb.save(out_path)


FILLS = {"ERROR": "F4B6B6", "NOT IMPORTED": "F4B6B6", "REJECT": "F4B6B6", "WARNING": "FFE699", "STAGE DESIGN ONLY": "F8CBAD",
         "DESIGNS ONLY": "FFE699", "IMPORTED": "E2EFDA", "IMPORT": "E2EFDA", "ACCEPTED": "C6E0B4"}


def table_sheet(wb, title, rows, widths=None, color_col=None):
    ws = wb.create_sheet(title)
    if not rows:
        ws.append(["(none)"])
        return
    cols = list(rows[0])
    ws.append(cols)
    for r in rows:
        ws.append([r.get(c) for c in cols])
    for c in ws[1]:
        c.font, c.fill = Font(bold=True), PatternFill("solid", fgColor="DDE4EE")
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.alignment = Alignment(wrap_text=True, vertical="top")
        if color_col and row[cols.index(color_col)].value in FILLS:
            row[cols.index(color_col)].fill = PatternFill("solid", fgColor=FILLS[row[cols.index(color_col)].value])
    for i, c in enumerate(cols, start=1):
        ws.column_dimensions[get_column_letter(i)].width = (widths or {}).get(c, min(45, max(10, len(c) + 2)))
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions


def suggestion_text(issues):
    out = [f"{c} -> {fmt_blank(v)} ({basis})" for i in issues for c, v, basis in i["suggest"]]
    return "; ".join(dict.fromkeys(out))


def issue_line(i, prefix=""):
    return f"[{i['level']}] {prefix}{LIKELY_CAUSE.get(i['check'], '')}: {i['detail']}"


def build_rows(res):
    st = S["settings"]
    sd_rows = [{"Name": sd["name"],
                "Description": f"Source design '{sd['key'][0]}'; {fmt(sd['key'][2])} clusters x {fmt(sd['key'][3])} shots; "
                               f"EHD {fmt(sd['key'][4])} in; {len(sd['wells'])} wells; rows {', '.join(str(w['row']) for w in sd['wells'])}",
                "Fluid Loading Value or Ratio": st["stage_fluid_mode"], "Sand and Fluid Unit": st["stage_sand_fluid_unit"],
                "Spacing Unit": st["stage_spacing_unit"], "Subsurface Equipment": sd["key"][5], "Clusters Per Stage": sd["key"][2],
                "Spacing": sd["key"][1], "Avg Fluid Loading": sd["key"][7], "Sand Loading": sd["key"][6]} for sd in res["sds"].values()]
    wd_rows = [{"Name": wd["name"], "Description": f"Benches {', '.join(sorted({str(w['bench']) for w in wd['wells']}))}; "
                                                   f"{len(wd['wells'])} wells; rows {', '.join(str(w['row']) for w in wd['wells'])}",
                "Target Lateral Length": wd["key"][0], "Pumping Plan": wd["key"][2], "Stage Design": wd["sd"]["name"],
                "Casing Design": wd["key"][1]} for wd in res["wds"].values()]
    pad_rows = []
    for p in res["pads"].values():
        if p["status"] != "IMPORT":
            continue
        d = p.get(st["start_date_source"])
        corr = sorted({o["cell"] for w in p["wells"] for o in w["overrides"]})
        row = {"Name": p["name"],
               "Description": f"Source pad '{p['pad_name']}', area {p['area']}, rig {p['rig']}, rows {p['wells'][0]['row']}-{p['wells'][-1]['row']}"
                              + (f"; engineer-accepted corrections: {', '.join(corr)}" if corr else ""),
               "Region": p["region"], "Subarea": p["area"], "Start Date": f"{d.isoformat()}T00:00:00.000{st['start_date_utc_offset']}",
               "Number of Wells": p["count"], "How should Well Designs be distributed amongst wells?": p["dist"], **p["assets"]}
        for i, (bench, wdn) in enumerate(p["slots"][:3], start=1):
            row[f"Type Curve Region {i}"], row[f"Well Design {i}"] = bench, wdn
        pad_rows.append(row)
    return sd_rows, wd_rows, pad_rows


def write_error_report(res, rows, files, schedule, out_path, accepted, review_name):
    wells, pads, src = res["wells"], res["pads"], res["src"]
    sd_rows, wd_rows, pad_rows = rows
    t = S["thresholds"]
    rep = Workbook()
    rep.remove(rep.active)
    n_err = sum(1 for w in wells for i in w["issues"] if i["level"] == "ERROR")
    nst = status_counts(res)
    ds = src["date_stats"]
    summary = [("Schedule", os.path.basename(schedule)), ("Run", dt.datetime.now().isoformat(timespec="seconds")),
               ("Script version", VERSION),
               ("Wells read", len(wells)),
               ("Wells fully imported (pad, well design, stage design)", nst["IMPORTED"]),
               ("Wells with well + stage design imported, pad held", nst["DESIGNS ONLY"]),
               ("Wells with stage design only (well design errors)", nst["STAGE DESIGN ONLY"]),
               ("Wells not imported (stage design errors)", nst["NOT IMPORTED"]),
               ("Wells with a stage design / a well design", f"{sum(1 for w in wells if w['sd_ok'])} / {sum(1 for w in wells if w['wd_ok'])}"),
               ("Pads read / imported", f"{len(pads)} / {len(pad_rows)}"),
               ("Stage Designs / Well Designs written", f"{len(sd_rows)} / {len(wd_rows)}"),
               ("Well-level ERRORs / WARNINGs", f"{n_err} / {sum(1 for w in wells for i in w['issues'] if i['level'] == 'WARNING')}"),
               ("Engineer-accepted corrections applied", len(accepted)),
               ("Dates read", f"{ds.get('native', 0)} as dates, {ds.get('serial', 0)} converted from Excel serial numbers, "
                              f"{ds.get('text', 0)} from text ({S['settings']['date_order']}), {ds.get('unreadable', 0)} unreadable"),
               ("Thresholds", f"LL screen {t['ll_screen_fraction']:g} x median; LL min/max {t['ll_min_ft']}/{t['ll_max_ft']} ft; "
                              f"stages {t['stage_count_min']}-{t['stage_count_max']}; SPE min spacing {t['spe_min_stage_spacing_ft']:g} ft"),
               ("Columns not found", ", ".join(src["missing_cols"]) or "none"),
               ("Units", "Written as stated in the schedule (ft, lb/ft, bbl/ft); confirm PrePad units before import"),
               ("Import rule", "Stage and Well Designs are evaluated well by well; a Pad is written only when all its wells are "
                               "ready for all three templates. Import order: Stage Design, Well Design, Pad"),
               ("Output files", "; ".join(v[0] for v in files.values()) + f"; {review_name}")]
    s = rep.create_sheet("Summary")
    for k, v in summary:
        s.append([k, v])
    s.append([])
    s.append(["Most frequent issues", "Wells"])
    hdr_row = s.max_row
    for (cid, desc), n in Counter((i["check"], i["description"]) for w in wells for i in w["issues"]).most_common(12):
        s.append([f"{cid} {desc}", n])
    s.column_dimensions["A"].width, s.column_dimensions["B"].width = 60, 100
    s["A1"].font = s.cell(hdr_row, 1).font = Font(bold=True)

    def accepted_text(w):
        return "; ".join(f"{o['cell']} {fmt_blank(o['original'])} -> {fmt_blank(o['new'])}" for o in w["overrides"])

    def blocking(w, tpl):
        return "; ".join(f"{i['check']} {i['detail']}" for i in w["issues"] if i["level"] == "ERROR" and i["template"] == tpl)

    not_full = [w for w in wells if w["status"] != "IMPORTED"]
    table_sheet(rep, "Wells_Not_Fully_Imported", [{
        "Status": w["status"], "Row": w["row"], "Well API": w["api"], "Rig": w["rig"], "Pad": pads[pad_key(w)]["name"],
        "Bench": w["bench"], **{f"{k} Import": v for k, v in template_states(w, pads[pad_key(w)]).items()},
        "Likely Cause": ", ".join(dict.fromkeys(LIKELY_CAUSE.get(i["check"], "") for i in w["issues"] if i["level"] == "ERROR"))
        or "Pad held (other wells)",
        "Suggested Correction (to confirm)": suggestion_text(w["issues"]),
        "Stage Design Errors": blocking(w, "Stage Design"), "Well Design Errors": blocking(w, "Well Design"),
        "Pad Errors (this well)": blocking(w, "Pad"),
        "Warnings": "; ".join(f"{i['check']}: {i['detail']}" for i in w["issues"] if i["level"] == "WARNING"),
        "Accepted Corrections": accepted_text(w)} for w in not_full],
        widths={"Pad": 28, "Likely Cause": 30, "Stage Design Import": 22, "Well Design Import": 26, "Pad Import": 34,
                "Stage Design Errors": 60, "Well Design Errors": 50, "Pad Errors (this well)": 40, "Warnings": 50,
                "Well API": 15, "Suggested Correction (to confirm)": 50, "Accepted Corrections": 40}, color_col="Status")
    table_sheet(rep, "Issue_Detail", [{
        "Row": w["row"], "Well API": w["api"], "Pad": pads[pad_key(w)]["name"], "Level": i["level"], "Check": i["check"],
        "Likely Cause": LIKELY_CAUSE.get(i["check"], ""), "Description": i["description"], "Detail": i["detail"],
        "Blocks Template": i["template"] if i["level"] == "ERROR" else "-",
        "Suggested Correction": suggestion_text([i]), "Well Status": w["status"]} for w in wells for i in w["issues"]] + [{
        "Row": p["row"], "Well API": "(pad)", "Pad": p["name"], "Level": i["level"], "Check": i["check"],
        "Likely Cause": LIKELY_CAUSE.get(i["check"], ""), "Description": i["description"], "Detail": i["detail"],
        "Blocks Template": "Pad" if i["level"] == "ERROR" else "-",
        "Suggested Correction": "", "Well Status": p["status"]} for p in pads.values() for i in p["issues"]],
        widths={"Pad": 28, "Description": 50, "Detail": 70, "Suggested Correction": 45}, color_col="Level")
    table_sheet(rep, "Pad_Status", [{
        "Status": p["status"], "PrePad Name": p["name"], "Rig": p["rig"], "Wells": len(p["wells"]),
        "Wells Not Ready": sum(1 for w in p["wells"] if not w["pad_ok"]),
        "Pad Errors": "; ".join(f"{i['check']}: {i['detail']}" for i in p["issues"] if i["level"] == "ERROR"),
        "Pad Warnings": "; ".join(f"{i['check']}: {i['detail']}" for i in p["issues"] if i["level"] == "WARNING")} for p in pads.values()],
        widths={"PrePad Name": 30, "Pad Errors": 70, "Pad Warnings": 70}, color_col="Status")
    lo, hi = t["stage_count_min"], t["stage_count_max"]
    table_sheet(rep, "Stage_Check", [{
        "Row": w["row"], "Pad": pads[pad_key(w)]["name"], "Design": w["completion_design"], "LL (ft)": w["ll"],
        "Clusters per Stage": w["clusters_per_stage"], "Cluster Spacing (ft)": w["cluster_spacing"],
        "Stage Length (ft)": w["stage_len"], "Stages as entered": round(w["stages"], 1) if w["stages"] else None,
        "Stages with suggested corrections": round(w["stages_corr"], 1) if w["stages_corr"] else None,
        "Result": "no calculation (value missing)" if w["stages"] is None else "OK" if lo <= w["stages"] <= hi else f"OUTSIDE {lo}-{hi}"}
        for w in wells], widths={"Pad": 28, "Design": 24, "Result": 22})

    # asset mapping coverage
    am = []
    imported_w = [w for w in wells if w["wd_ok"]]          # wells whose well design is written
    imported_p = [p for p in pads.values() if p["status"] == "IMPORT"]
    for tpl, column, key in ASSET_FIELDS:
        rules = [r for r in S["asset_mapping"].get(key) or [] if str(r.get("value") or "").strip()]
        if key in ("pumping_plan", "casing_design", "subsurface_equipment"):
            mapped = [w for w in imported_w if map_asset(key, w)[0]]
            unm = sorted({str(w.get({"pumping_plan": "completion_design", "casing_design": "casing",
                                     "subsurface_equipment": "plug_type"}[key])) for w in imported_w if not map_asset(key, w)[0]})
            fallback = {"pumping_plan": "blank", "casing_design": "casing text from schedule",
                        "subsurface_equipment": "plug type from schedule"}[key]
            am.append({"Template": tpl, "PrePad Column": column, "Config Key": f"asset_mapping.{key}", "Rules": len(rules),
                       "Imported Wells Mapped": f"{len(mapped)} of {len(imported_w)}", "Without a Rule (uses fallback)": fallback,
                       "Source Values Without a Rule": ", ".join(unm)})
        else:
            mapped = [p for p in imported_p if column in p["assets"]]
            unm = sorted({str(w.get("frac_provider")) for p in imported_p if column not in p["assets"] for w in p["wells"]})
            am.append({"Template": tpl, "PrePad Column": column, "Config Key": f"asset_mapping.{key}", "Rules": len(rules),
                       "Imported Wells Mapped": f"{len(mapped)} of {len(imported_p)} pads", "Without a Rule (uses fallback)": "blank",
                       "Source Values Without a Rule": f"pads with frac provider {', '.join(unm)}" if unm else ""})
    table_sheet(rep, "Asset_Mapping", am, widths={"PrePad Column": 34, "Config Key": 34, "Source Values Without a Rule": 60})

    missing = [{"Part": "A - PrePad field with no source", "Template": tpl, "Field / Column": f,
                "Records affected": f"all {len({'Stage Design': sd_rows, 'Well Design': wd_rows, 'Pad': pad_rows}[tpl])} imported {tpl} records",
                "Why": why, "Action": act} for tpl, f, why, act in NO_SOURCE_FIELDS]
    for tpl, column, key in ASSET_FIELDS:
        rws = {"Stage Design": sd_rows, "Well Design": wd_rows, "Pad": pad_rows}[tpl]
        n = sum(1 for r in rws if not r.get(column))
        if n:
            missing.append({"Part": "A - PrePad field with no source", "Template": tpl, "Field / Column": column,
                            "Records affected": f"{n} of {len(rws)} imported {tpl} records",
                            "Why": "No source column and no asset_mapping rule matched",
                            "Action": f"Add a rule under asset_mapping.{key} in the config file (see --init-config)"})
    blanks = defaultdict(list)
    for w in wells:
        for k in SOURCE_COLUMNS:
            if w.get(k) in (None, ""):
                blanks[k].append(w["row"])
    for k, rws in blanks.items():
        missing.append({"Part": "B - Blank in schedule", "Template": "-", "Field / Column": f"{src['col'].get(k, '?')}: {SOURCE_COLUMNS[k][0]}",
                        "Records affected": f"{len(rws)} wells: rows {', '.join(map(str, rws))}", "Why": "Cell empty in source",
                        "Action": "Client to supply or confirm not applicable"})
    n = sum(1 for r in pad_rows if not r.get("How should Well Designs be distributed amongst wells?"))
    if n:
        missing.append({"Part": "C - Blank in import file", "Template": "Pad", "Field / Column": "How should Well Designs be distributed amongst wells?",
                        "Records affected": f"{n} of {len(pad_rows)}", "Why": "Single-design pads have no documented option",
                        "Action": "PrePad admin to confirm"})
    table_sheet(rep, "Missing_Data", missing, widths={"Field / Column": 40, "Records affected": 60, "Why": 50, "Action": 50})
    table_sheet(rep, "Accepted_Corrections", [{
        "Cell": a["cell"], "Row": a["row"], "Pad": a["pad"], "Field": a["field"], "Original": fmt_blank(a["original"]),
        "Suggested Value": fmt_blank(a.get("suggested", a["new"])), "Accepted Value": fmt_blank(a["new"]),
        "Source of Value": "Engineer override" if a.get("user_override") else "Suggestion accepted", "Check": a["check"], "Basis": a["basis"], "Engineer": a.get("engineer"),
        "Accepted At": a.get("accepted_at"), "Client Confirmation": "pending"} for a in accepted],
        widths={"Pad": 28, "Basis": 60})
    table_sheet(rep, "Well_Import_Status", [{"Status": w["status"], "Row": w["row"], "Well API": w["api"],
                                             "Pad": pads[pad_key(w)]["name"], "Bench": w["bench"],
                                             "Stage Design": w.get("sd_name") or "(held)", "Well Design": w.get("wd_name") or "(held)",
                                             "Pad Import": "Yes" if w["status"] == "IMPORTED" else "No",
                                             "Pumping Plan": w.get("pumping_plan"), "Accepted Corrections": accepted_text(w),
                                             "Warnings": "; ".join(f"{i['check']}: {i['detail']}" for i in w["issues"] if i["level"] == "WARNING")}
                                            for w in wells],
                widths={"Pad": 28, "Well Design": 34, "Stage Design": 44, "Warnings": 60, "Accepted Corrections": 40}, color_col="Status")
    table_sheet(rep, "Checks", [{"Check": k, "Level": v[0], "Scope": v[1],
                                "Blocks (if ERROR)": CHECK_TEMPLATE.get(k) or ("Pad" if k.startswith("P") else "by field: stage, well or pad"),
                                "Likely Cause": LIKELY_CAUSE.get(k, ""), "Description": v[2]} for k, v in CHECKS.items()],
                widths={"Description": 100, "Blocks (if ERROR)": 26}, color_col="Level")
    rep.save(out_path)
    return summary


CLIENT_STATUS = {"IMPORTED": "OK",
                 "DESIGNS ONLY": "Designs loaded - pad on hold",
                 "STAGE DESIGN ONLY": "Correction needed - stage design loaded, well design on hold",
                 "NOT IMPORTED": "Correction needed - not loaded"}
CLIENT_RESPONSES = ["Accept suggested correction", "Corrected value entered in the cell", "Value is correct as entered",
                    "Other - see comment"]


def write_client_review(schedule, res, out_path, accepted=()):
    """Copy of the client's schedule in its original layout. Flagged cells highlighted with a comment; columns added
    to the right for status, reasoning, suggested correction, stage check and client response. Data cells unchanged."""
    src, wells, pads = res["src"], res["wells"], res["pads"]
    eng_value = {a["cell"]: a for a in accepted if a.get("user_override")}

    def acc_note(o):
        a = eng_value.get(o["cell"])
        return f" (our engineer's value; we had suggested {fmt_blank(a.get('suggested'))})" if a else ""
    wb = load_workbook(schedule)
    ws = wb[src["sheet"]]
    hr = src["header_row"]
    last = max(c.column for c in ws[hr] if c.value is not None)
    cols = ["QC Status", "QC Findings & Reasoning", "Suggested Correction (please confirm)", "Calc. Stage Length (ft)",
            "Calc. Stages (as entered)", "Calc. Stages (with corrections)", "Client Response", "Client Comment"]
    widths = [22, 80, 55, 12, 12, 14, 26, 40]
    ref = ws.cell(hr, last)
    for k, (title, wdt) in enumerate(zip(cols, widths), start=1):
        c = ws.cell(hr, last + k, title)
        c.font, c.fill, c.border = copymod.copy(ref.font), copymod.copy(ref.fill), copymod.copy(ref.border)
        c.alignment = Alignment(wrap_text=True, horizontal="center", vertical="center")
        ws.column_dimensions[get_column_letter(last + k)].width = wdt
    C = {t_: last + k for k, t_ in enumerate(cols, start=1)}
    fill = {k: PatternFill("solid", fgColor=v) for k, v in
            {"ERROR": "F4B6B6", "WARNING": "FFE699", "STANDARD": "DDEBF7", "ACCEPTED": "C6E0B4"}.items()}
    rank = {"STANDARD": 1, "ACCEPTED": 2, "WARNING": 3, "ERROR": 4}
    painted, notes = {}, defaultdict(list)

    def top_left(addr):
        if isinstance(ws[addr], MergedCell):
            for mr in ws.merged_cells.ranges:
                if addr in mr:
                    return ws.cell(mr.min_row, mr.min_col).coordinate
        return addr

    def paint(addr, kind, text):
        addr = top_left(addr)
        if rank[kind] > rank.get(painted.get(addr), 0):
            ws[addr].fill = fill[kind]
            painted[addr] = kind
        notes[addr].append(text)

    for obj in list(wells) + list(pads.values()):
        for i in obj["issues"]:
            if i["check"] in ("W33", "P02"):
                continue
            kind = "STANDARD" if i["check"] in ("W27", "W38") else i["level"]
            for addr in i["cells"]:
                paint(addr, kind, issue_line(i))
        for o in obj.get("overrides", []):
            paint(o["cell"], "ACCEPTED", f"[ACCEPTED] {fmt_blank(o['original'])} -> {fmt_blank(o['new'])}{acc_note(o)}: correction accepted by "
                                         f"the engineer and used for the import; please confirm")
    for addr, lines in notes.items():
        cm = Comment("\n".join(dict.fromkeys(lines))[:1500], "PrePad QC")
        cm.width, cm.height = 420, 160
        ws[addr].comment = cm

    dv = DataValidation(type="list", formula1='"' + ",".join(CLIENT_RESPONSES) + '"', allow_blank=True)
    ws.add_data_validation(dv)
    order = {"ERROR": 0, "WARNING": 1}
    first_of_pad = {pad_key(p["wells"][0]): p["wells"][0]["row"] for p in pads.values()}
    for w in wells:
        r, p = w["row"], pads[pad_key(w)]
        lines = [f"[ACCEPTED] {o['cell']} {fmt_blank(o['original'])} -> {fmt_blank(o['new'])}{acc_note(o)} (engineer-accepted; please confirm)"
                 for o in w["overrides"]]
        lines += [issue_line(i) for i in sorted(w["issues"], key=lambda i: order[i["level"]]) if i["check"] != "W33"]
        if first_of_pad[pad_key(w)] == r:
            lines += [issue_line(i, "Pad - ") for i in sorted(p["issues"], key=lambda i: order[i["level"]]) if i["check"] != "P02"]
        own_err = any(i["level"] == "ERROR" for i in w["issues"])
        if w["status"] == "DESIGNS ONLY":
            bad = [str(x["row"]) for x in p["wells"] if not x["pad_ok"] and x is not w]
            if own_err and bad:
                lines.insert(0, f"[INFO] Well and stage design loaded. The pad loads when this row and row(s) {', '.join(bad)} are corrected")
            elif own_err:
                lines.insert(0, "[INFO] Well and stage design loaded. The pad loads when this row is corrected")
            elif bad:
                lines.insert(0, f"[INFO] This well is clean and its designs are loaded; the pad loads when row(s) {', '.join(bad)} are corrected")
            else:
                lines.insert(0, "[INFO] This well is clean and its designs are loaded; the pad is held by a pad-level finding")
        status = CLIENT_STATUS[w["status"]]
        if w["status"] == "DESIGNS ONLY" and own_err:
            status = "Correction needed (pad data) - designs loaded"
        if w["status"] == "IMPORTED" and w["overrides"]:
            status = "OK - pending your confirmation of accepted corrections"
        elif w["status"] == "IMPORTED" and lines:
            status += " - see notes"
        values = {"QC Status": status, "QC Findings & Reasoning": "\n".join(f"{n}. {t_}" for n, t_ in enumerate(lines, start=1)),
                  "Suggested Correction (please confirm)": suggestion_text(w["issues"]).replace("; ", "\n"),
                  "Calc. Stage Length (ft)": round(w["stage_len"], 1) if w["stage_len"] else None,
                  "Calc. Stages (as entered)": round(w["stages"], 1) if w["stages"] else None,
                  "Calc. Stages (with corrections)": round(w["stages_corr"], 1) if w["stages_corr"] else None}
        for t_, v in values.items():
            ws.cell(r, C[t_], v).alignment = Alignment(wrap_text=True, vertical="top")
        ws.cell(r, C["QC Status"]).fill = fill["ACCEPTED"] if status.startswith("OK") else \
            fill["ERROR"] if own_err else fill["WARNING"]
        dv.add(ws.cell(r, C["Client Response"]))

    rm = wb.create_sheet("QC_Read_Me", 1)
    n = Counter(w["status"] for w in wells)
    ds = src["date_stats"]
    t = S["thresholds"]
    lines = [
        ("PrePad intake QC - client review", None),
        (f"Schedule: {os.path.basename(schedule)}   |   QC run: {dt.datetime.now():%Y-%m-%d %H:%M}", None), ("", None),
        ("Purpose: please verify the flagged entries and approve or correct them before the schedule is loaded into PrePad.", None),
        (f"Sheet '{ws.title}' is your schedule in its original layout. No data cell has been changed; flagged cells are highlighted "
         f"and carry a comment, and columns {get_column_letter(last + 1)} to {get_column_letter(last + len(cols))} have been added.", None),
        ("", None), ("Colour legend", None),
        ("Must be corrected or confirmed before import (holds the affected design for this well, and its pad)", "ERROR"),
        ("Please check: does not block import, or is a suggested value to confirm", "WARNING"),
        ("Correction accepted by our engineer and used for the import - please confirm", "ACCEPTED"),
        ("Standardised by QC (naming convention); no action unless you disagree", "STANDARD"), ("", None),
        ("How to respond", None),
        ("1. Read 'QC Findings & Reasoning' and 'Suggested Correction' on each highlighted row.", None),
        (f"2. Choose a 'Client Response': {'; '.join(CLIENT_RESPONSES)}.", None),
        ("3. If you correct a value, overwrite the cell and choose 'Corrected value entered in the cell'.", None),
        ("4. Suggested values (e.g. fracture gradients from offset wells) are proposals only and will not be used until you confirm them.", None),
        ("5. Return this workbook. Stage and well designs are loaded well by well; a pad is loaded only when all its wells are confirmed.", None), ("", None),
        (f"Wells: {len(wells)}  |  Fully loaded: {n.get('IMPORTED', 0)}  |  Designs loaded, pad on hold: {n.get('DESIGNS ONLY', 0)}  |  "
         f"Stage design only: {n.get('STAGE DESIGN ONLY', 0)}  |  Not loaded: {n.get('NOT IMPORTED', 0)}", None),
        (f"Stage count check: stages = lateral length / (clusters per stage x cluster spacing); expected "
         f"{t['stage_count_min']}-{t['stage_count_max']} stages per well.", None),
    ]
    if ds.get("serial") or ds.get("text"):
        lines.append((f"Formatting note: {ds.get('serial', 0)} dates were stored as numbers and {ds.get('text', 0)} as text; they were "
                      "read automatically, but please format them as dates.", None))
    for text, kind in lines:
        rm.append([text])
        if kind:
            rm.cell(rm.max_row, 1).fill = fill[kind]
    rm["A1"].font = Font(bold=True, size=14)
    for r_ in range(1, rm.max_row + 1):
        if rm.cell(r_, 1).value in ("Colour legend", "How to respond"):
            rm.cell(r_, 1).font = Font(bold=True)
        rm.cell(r_, 1).alignment = Alignment(wrap_text=True, vertical="top")
    rm.column_dimensions["A"].width = 150
    wb.calculation.fullCalcOnLoad = True
    wb.save(out_path)


# =====================================================================================
# 7. CONFIG TEMPLATE
# =====================================================================================

def write_config_template(schedule, path, today):
    """Write a config file with the current settings and asset-mapping rules pre-filled with every distinct source
    value found in the schedule (values left empty for the engineer to fill)."""
    cfg = config_template_dict(schedule, today)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
    print(f"Config template written: {path}\nEdit it, then run with --config {path}")


def config_template_dict(schedule, today):
    res = analyze(schedule, today)
    wells = res["wells"]

    def distinct(f):
        return sorted({w[f] for w in wells if w.get(f)})
    cfg = copymod.deepcopy({k: v for k, v in S.items() if k in DEFAULTS})
    cfg["_comment"] = ("Fill in 'value' with the exact PrePad name. Rules with an empty value are ignored. First matching rule wins. "
                       f"Match fields: {', '.join(MATCH_FIELDS)}; a list matches any of its values; '*' matches any non-blank value.")
    am = cfg["asset_mapping"]
    am["pumping_plan"] = [{"match": {"completion_design": d}, "value": ""} for d in distinct("completion_design")]
    am["casing_design"] = [{"match": {"casing": c}, "value": ""} for c in distinct("casing")]
    am["subsurface_equipment"] = [{"match": {"plug_type": p_}, "value": ""} for p_ in distinct("plug_type")]
    am["frac_spread"] = [{"match": {"frac_provider": f}, "value": ""} for f in distinct("frac_provider")]
    am["wireline_equipment"] = [{"match": {"rig": r}, "value": ""} for r in distinct("rig")] + [{"match": {}, "value": ""}]
    am["launcher_equipment"] = [{"match": {}, "value": ""}]
    am["well_prioritization"] = [{"match": {}, "value": ""}]
    am["prioritization_mode"] = [{"match": {}, "value": ""}]
    return cfg


# =====================================================================================
# 8. MAIN
# =====================================================================================

def output_dir_for(schedule, stamp):
    sub = (S["settings"].get("output_subfolder") or "").strip()
    folder = os.path.dirname(os.path.abspath(schedule))
    return os.path.join(folder, sub.format(stamp=stamp)) if sub else folder


def write_outputs(schedule, templates, res, accepted, out_dir, stamp):
    """Write the three import files, the error report, the client review copy and (if any) the resolutions log.
    Returns {"files": [paths], "summary": [(label, value)]}."""
    os.makedirs(out_dir, exist_ok=True)
    rows = build_rows(res)
    files = {"Stage Design": (f"PrePad_Stage_Design_Import_{stamp}.xlsx", SD_HDR, rows[0]),
             "Well Design": (f"PrePad_Well_Design_Import_{stamp}.xlsx", WD_HDR, rows[1]),
             "Pad": (f"PrePad_Pad_Import_{stamp}.xlsx", PAD_HDR, rows[2])}
    for t_, (fn, hdr, rws) in files.items():
        write_import(templates[t_], os.path.join(out_dir, fn), hdr, rws)
    review_name = f"{os.path.splitext(os.path.basename(schedule))[0]}_QC_Client_Review_{stamp}.xlsx"
    rep_name = f"PrePad_Error_Report_{stamp}.xlsx"
    summary = write_error_report(res, rows, files, schedule, os.path.join(out_dir, rep_name), accepted, review_name)
    write_client_review(schedule, res, os.path.join(out_dir, review_name), accepted)
    names = [v[0] for v in files.values()] + [rep_name, review_name]
    if accepted:
        res_name = f"resolutions_{stamp}.json"
        with open(os.path.join(out_dir, res_name), "w", encoding="utf-8") as f:
            json.dump({"schedule": os.path.basename(schedule), "created": dt.datetime.now().isoformat(timespec="seconds"),
                       "corrections": accepted}, f, indent=2, default=str)
        names.append(res_name)
    return {"files": [os.path.join(out_dir, n) for n in names], "summary": summary, "rows": rows}


def parse_args(argv=None):
    ap = argparse.ArgumentParser(description="Build PrePad import files from clean schedule data and report the rest.",
                                 formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    ap.add_argument("--input", default=DEFAULT_INPUT, help="folder with the schedule (and optional PrePad templates), or the schedule file")
    ap.add_argument("--output", default=None, help="output folder (default: <input folder>/output_<timestamp>)")
    ap.add_argument("--today", default=None, help="date for 'before today' checks, YYYY-MM-DD")
    ap.add_argument("--config", default=None, help="JSON config file (thresholds, settings, bench_aliases, asset_mapping)")
    ap.add_argument("--init-config", default=None, metavar="PATH", help="write a config template pre-filled from the schedule and exit")
    g = ap.add_argument_group("threshold overrides (take precedence over the config file)")
    g.add_argument("--ll-screen-fraction", type=float, help="flag LL below this fraction of the median (default 0.10)")
    g.add_argument("--ll-min-ft", type=float, help="absolute minimum LL in ft")
    g.add_argument("--ll-max-ft", type=float, help="absolute maximum LL in ft (e.g. 20000)")
    g.add_argument("--stage-min", type=int, help="minimum stages per well (default 15)")
    g.add_argument("--stage-max", type=int, help="maximum stages per well (default 120)")
    g.add_argument("--spe-min-spacing", type=float, help="minimum single-point-entry stage spacing in ft (default 100)")
    g.add_argument("--pending-design", choices=["error", "warning"], help="treat 'Pending Review' designs as error (default) or warning")
    g.add_argument("--date-order", choices=["MDY", "DMY"], help="order of numeric text dates such as 03/04/2025 (default MDY)")
    r = ap.add_argument_group("corrections")
    r.add_argument("--interactive", action="store_true", help="review and accept suggested corrections before building import files")
    r.add_argument("--engineer", default=os.environ.get("USERNAME") or os.environ.get("USER") or "engineer",
                   help="name recorded with accepted corrections")
    r.add_argument("--resolutions", default=None, help="replay accepted corrections from a resolutions_<stamp>.json file")
    return ap.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    try:
        activate(load_settings(args))
    except ConfigError as e:
        sys.exit(str(e))
    today = dt.date.fromisoformat(args.today) if args.today else dt.date.today()
    schedule, templates = find_inputs(args.input, S["settings"]["schedule_glob"],
                                      [os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates")])

    if args.init_config:
        write_config_template(schedule, args.init_config, today)
        return

    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out = args.output or output_dir_for(schedule, stamp)
    print(f"PrePad clean import v{VERSION}\nSchedule : {schedule}\nConfig   : {args.config or 'built-in defaults'}")
    for k, v in templates.items():
        print(f"Template : {k}: {os.path.basename(v) if v else 'not found (headers written by script)'}")

    accepted = load_resolutions(args.resolutions, schedule) if args.resolutions else []
    if args.resolutions:
        print(f"Replaying {len(accepted)} correction(s) from {args.resolutions}")
    res = analyze(schedule, today, {a["cell"]: a["new"] for a in accepted})
    if res["src"]["missing_cols"]:
        print(f"WARNING: columns not found in schedule: {res['src']['missing_cols']}")
    if args.interactive:
        n0 = sum(1 for w in res["wells"] if w["status"] == "IMPORTED")
        new = interactive_session(res, args.engineer)
        if new:
            accepted = [a for a in accepted if a["cell"] not in {x["cell"] for x in new}] + new
            res = analyze(schedule, today, {a["cell"]: a["new"] for a in accepted})
            print(f"Re-analysed with accepted corrections: wells fully imported {n0} -> {sum(1 for w in res['wells'] if w['status'] == 'IMPORTED')}")

    result = write_outputs(schedule, templates, res, accepted, out, stamp)
    summary, out_files = result["summary"], [os.path.basename(f) for f in result["files"]]
    print()
    for k, v in summary[3:13]:
        print(f"{k:55s} {v}")
    print(f"\nOutput folder: {out}\n  " + "\n  ".join(out_files))
    print("\nSend the *_QC_Client_Review file to the client for verification and approval.")
    print("Nothing is approved for import until an engineer has reviewed the error report.")


if __name__ == "__main__":
    main()
