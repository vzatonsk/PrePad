PrePad Intake QC - Streamlit app (engine v2.1)
=============================================

FIRST RUN
1. Unzip this folder anywhere (e.g. C:\Users\vzato\Tools\PrePad_App). Keep the files together.
2. Python 3.10+ must be installed (python.org installer, tick "Add python.exe to PATH").
3. Double-click run_prepad_app.bat. The first start creates a private .venv and installs
   openpyxl + streamlit (needs internet once, ~1-2 min). Later starts take a few seconds.
4. The app opens in your browser at http://localhost:8501. Close the black window to stop it.

RUN TAB
- "Browse for schedule..." opens a Windows file dialog (starts in C:\Users\vzato\Downloads\Prepad).
  The schedule is analysed immediately and all outputs are saved IN THE SAME FOLDER as the schedule:
    PrePad_Stage_Design_Import_<stamp>.xlsx, PrePad_Well_Design_Import_<stamp>.xlsx,
    PrePad_Pad_Import_<stamp>.xlsx, PrePad_Error_Report_<stamp>.xlsx,
    <schedule>_QC_Client_Review_<stamp>.xlsx  (intake format + QC reasoning column - send to client)
- You can also paste a full path and press Analyse.
- Upload (drag and drop): a browser does not reveal where a file came from, so the uploaded copy is
  saved to the folder you type (default Downloads\Prepad) and the outputs go next to that copy.
- Section 3 lists the suggested corrections in batches (LL x1000, SPE spacing 25 -> 250, offset frac
  gradient, copy-paste row 41, fill-out gaps...). Tick Accept, or type your own value in the
  User Change column (one value for the batch, or CELL=value; CELL=value, 'blank' clears a cell) -
  your value overrides the suggestion and is logged as an engineer override. Enter your name, press Apply: the files
  are regenerated with a new time stamp and resolutions_<stamp>.json logs every accepted change.
  The schedule itself is never modified. A resolutions file can be replayed on a later revision.

CONFIGURATION TAB
- Pre-populated with the built-in guidance (screening thresholds, settings, bench aliases, asset
  mapping for Pumping Plans / Frac Spreads / Wireline Units). Any field can be overridden; each
  override shows the guidance default beside it. "Save configuration" writes prepad_config.json
  next to the app; "Reset to guidance" restores the defaults. Download / load JSON is supported.

TEMPLATES
- The three PrePad upload templates are in templates\. If a PrePad template changes, replace the
  file there (same name), or put the new templates in the schedule folder - those take precedence.

COMMAND LINE (optional, unchanged)
  .venv\Scripts\python prepad_clean_import.py "C:\path\schedule.xlsx" [--config prepad_config.json] [--interactive]
