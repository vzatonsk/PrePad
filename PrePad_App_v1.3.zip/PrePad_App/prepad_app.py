"""
PrePad Intake QC - Streamlit app
================================
Start with run_prepad_app.bat (Windows), or:  python -m streamlit run prepad_app.py

Run tab        select a customer schedule -> it is analysed and all output files are written automatically to the
               schedule's folder -> review results -> optionally accept suggested corrections and regenerate.
Configuration  thresholds, settings, bench naming and PrePad asset mapping, pre-populated with the built-in guidance;
               any value can be overridden and saved to prepad_config.json next to this app.
Help           workflow, output files and the full check catalogue.

The analysis engine is prepad_clean_import.py (same folder); the app adds no checks of its own.
"""
import copy
import datetime as dt
import json
import os
import subprocess
import sys

import pandas as pd
import streamlit as st

APP_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, APP_DIR)
import prepad_clean_import as eng  # noqa: E402

CONFIG_PATH = os.path.join(APP_DIR, "prepad_config.json")
TEMPLATE_DIR = os.path.join(APP_DIR, "templates")
CONFIG_KEYS = ["thresholds", "settings", "bench_aliases", "asset_mapping"]

st.set_page_config(page_title="PrePad Intake QC", layout="wide")
ss = st.session_state


# ------------------------------------------------------------------------------------------------
# state and configuration helpers
# ------------------------------------------------------------------------------------------------

def clean_cfg(cfg):
    return {k: copy.deepcopy(cfg[k]) for k in CONFIG_KEYS}


def load_cfg_file():
    """Saved configuration merged over the built-in defaults; falls back to defaults if the file is invalid."""
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, encoding="utf-8") as f:
                return clean_cfg(eng.settings_from_dict(json.load(f))), None
        except (json.JSONDecodeError, eng.ConfigError, OSError) as e:
            return clean_cfg(eng.DEFAULTS), f"{CONFIG_PATH} could not be used ({e}); built-in defaults loaded."
    return clean_cfg(eng.DEFAULTS), None


def init_state():
    if "cfg" not in ss:
        ss.cfg, ss.cfg_warning = load_cfg_file()
        ss.cfg_ver = 0
        ss.schedule = None
        ss.res = None
        ss.outputs = []
        ss.summary = []
        ss.accepted = []
        ss.history = []
        ss.run_id = 0
        ss.engineer = os.environ.get("USERNAME") or os.environ.get("USER") or ""
        ss.last_error = None


def validated_cfg():
    """Return (cfg, error). cfg is the merged, validated configuration or None."""
    try:
        return eng.settings_from_dict(ss.cfg), None
    except eng.ConfigError as e:
        return None, str(e)


def bump_cfg():
    ss.cfg_ver += 1      # forces config widgets to re-read values after a reset / load


# ------------------------------------------------------------------------------------------------
# analysis
# ------------------------------------------------------------------------------------------------

def run_analysis(path, accepted, reason):
    """Analyse the schedule and write every output file into the schedule's folder."""
    cfg, err = validated_cfg()
    if err:
        ss.last_error = f"Configuration is not valid - fix it on the Configuration tab first. {err}"
        return
    eng.activate(cfg)
    ss.last_error = None
    with st.status(f"{reason}: analysing {os.path.basename(path)} ...", expanded=False) as status:
        try:
            _, templates = eng.find_inputs(path, cfg["settings"]["schedule_glob"], [TEMPLATE_DIR])
            res = eng.analyze(path, dt.date.today(), {a["cell"]: a["new"] for a in accepted})
            status.update(label="Writing output files ...")
            stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
            out_dir = eng.output_dir_for(path, stamp)
            result = eng.write_outputs(path, templates, res, accepted, out_dir, stamp)
        except SystemExit as e:            # engine reports problems such as a missing header row this way
            ss.last_error = str(e)
            status.update(label="Analysis failed", state="error")
            return
        except PermissionError as e:
            ss.last_error = (f"Could not write to {os.path.dirname(path)}: {e}. Close any output file that is open in Excel "
                             "and try again.")
            status.update(label="Could not write output files", state="error")
            return
        status.update(label=f"Done - {len(result['files'])} files saved to {out_dir}", state="complete")
    ss.schedule, ss.res, ss.outputs, ss.summary, ss.accepted = path, res, result["files"], result["summary"], list(accepted)
    ss.templates = templates
    ss.run_id += 1
    ss.history.insert(0, {"Time": dt.datetime.now().strftime("%H:%M:%S"), "Run": reason,
                          "Wells fully imported": sum(1 for w in res["wells"] if w["status"] == "IMPORTED"),
                          "Wells with well design": sum(1 for w in res["wells"] if w["wd_ok"]),
                          "Wells with stage design": sum(1 for w in res["wells"] if w["sd_ok"]),
                          "Pads imported": sum(1 for p in res["pads"].values() if p["status"] == "IMPORT"),
                          "Accepted corrections": len(accepted), "Folder": out_dir})


def browse_for_schedule(initial_dir):
    """Native Windows file dialog (tkinter, run in a separate process). Returns a path, '' if cancelled, None if unavailable."""
    code = ("import sys, tkinter as tk, tkinter.filedialog as fd\n"
            "r = tk.Tk(); r.withdraw(); r.attributes('-topmost', True)\n"
            "p = fd.askopenfilename(initialdir=sys.argv[1], title='Select the customer schedule',\n"
            "                       filetypes=[('Excel workbook', '*.xlsx *.xlsm'), ('All files', '*.*')])\n"
            "print(p)\n")
    try:
        out = subprocess.run([sys.executable, "-c", code, initial_dir if os.path.isdir(initial_dir) else os.path.expanduser("~")],
                             capture_output=True, text=True, timeout=900)
    except (OSError, subprocess.TimeoutExpired):
        return None
    if out.returncode != 0:
        return None
    return os.path.normpath(out.stdout.strip()) if out.stdout.strip() else ""


def save_upload(uploaded, folder):
    """Save an uploaded schedule into folder (outputs are written next to it). Re-uses an identical existing file."""
    os.makedirs(folder, exist_ok=True)
    data = uploaded.getvalue()
    target = os.path.join(folder, uploaded.name)
    if os.path.exists(target):
        with open(target, "rb") as f:
            if f.read() == data:
                return target
        stem, ext = os.path.splitext(uploaded.name)
        target = os.path.join(folder, f"{stem}_uploaded_{dt.datetime.now():%Y%m%d_%H%M%S}{ext}")
    with open(target, "wb") as f:
        f.write(data)
    return target


# ------------------------------------------------------------------------------------------------
# result tables
# ------------------------------------------------------------------------------------------------

def wells_table(res):
    pads = res["pads"]
    rows = []
    for w in res["wells"]:
        if w["status"] == "IMPORTED":
            continue
        errs = [i for i in w["issues"] if i["level"] == "ERROR"]
        tpl = eng.template_states(w, pads[eng.pad_key(w)])
        rows.append({"Status": w["status"], "Row": w["row"], "Well API": w["api"], "PrePad pad": pads[eng.pad_key(w)]["name"],
                     "Bench": w["bench"], "Stage design": tpl["Stage Design"], "Well design": tpl["Well Design"], "Pad import": tpl["Pad"],
                     "Likely cause": ", ".join(dict.fromkeys(eng.LIKELY_CAUSE.get(i["check"], "") for i in errs)) or "Pad held (other wells)",
                     "Errors": "; ".join(f"{i['check']} [{i['template']}]: {i['detail']}" for i in errs),
                     "Suggested correction": eng.suggestion_text(w["issues"])})
    return pd.DataFrame(rows)


def pads_table(res):
    return pd.DataFrame([{"Status": p["status"], "PrePad name": p["name"], "Wells": len(p["wells"]),
                          "Wells not ready": sum(1 for w in p["wells"] if not w["pad_ok"]),
                          "Pad errors": "; ".join(f"{i['check']}: {i['detail']}" for i in p["issues"] if i["level"] == "ERROR"),
                          "Pad warnings": "; ".join(f"{i['check']}: {i['detail']}" for i in p["issues"] if i["level"] == "WARNING")}
                         for p in res["pads"].values()])


def stage_table(res):
    lo, hi = eng.S["thresholds"]["stage_count_min"], eng.S["thresholds"]["stage_count_max"]
    return pd.DataFrame([{"Row": w["row"], "Pad": res["pads"][eng.pad_key(w)]["name"], "Design": w["completion_design"],
                          "LL (ft)": w["ll"], "Clusters": w["clusters_per_stage"], "Spacing (ft)": w["cluster_spacing"],
                          "Stage length (ft)": w["stage_len"], "Stages as entered": round(w["stages"], 1) if w["stages"] else None,
                          "Stages with suggestions": round(w["stages_corr"], 1) if w["stages_corr"] else None,
                          "Result": "missing value" if w["stages"] is None else "OK" if lo <= w["stages"] <= hi else f"outside {lo}-{hi}"}
                         for w in res["wells"]])


def missing_table(res):
    rows = [{"PrePad field": f"{t}: {f}", "Status": "No source in schedule", "Action": act} for t, f, _, act in eng.NO_SOURCE_FIELDS]
    imported_w = [w for w in res["wells"] if w["wd_ok"]]       # wells whose well design is written
    imported_p = [p for p in res["pads"].values() if p["status"] == "IMPORT"]
    for tpl, column, key in eng.ASSET_FIELDS:
        if key in ("casing_design", "subsurface_equipment"):
            continue      # these fall back to schedule values
        if key == "pumping_plan":
            n, tot = sum(1 for w in imported_w if w.get("pumping_plan")), len(imported_w)
            unit = "wells with a well design"
        else:
            n, tot = sum(1 for p in imported_p if column in p["assets"]), len(imported_p)
            unit = "imported pads"
        rows.append({"PrePad field": f"{tpl}: {column}", "Status": f"Mapped for {n} of {tot} {unit}",
                     "Action": "" if n == tot and tot else f"Add a rule on the Configuration tab (asset mapping: {key})"})
    return pd.DataFrame(rows)


# ------------------------------------------------------------------------------------------------
# RUN TAB
# ------------------------------------------------------------------------------------------------

def run_tab():
    cfg_ok, cfg_err = validated_cfg()
    if cfg_err:
        st.error(f"The configuration is not valid, so analysis is disabled. {cfg_err}")
    st.subheader("1. Select the customer schedule")
    st.caption("The schedule is analysed as soon as it is selected. All output files are saved automatically in the same "
               "folder as the schedule" + (f" (subfolder '{ss.cfg['settings']['output_subfolder']}')"
                                           if ss.cfg["settings"]["output_subfolder"] else "") + ".")
    default_folder = ss.cfg["settings"]["default_folder"]
    c1, c2 = st.columns([1, 3])
    with c1:
        if st.button("Browse for schedule...", type="primary", disabled=bool(cfg_err), width="stretch"):
            p = browse_for_schedule(os.path.dirname(ss.schedule) if ss.schedule else default_folder)
            if p is None:
                st.warning("The file browser is not available on this machine. Paste the path or upload the file instead.")
            elif p:
                run_analysis(p, [], "New schedule")
    with c2:
        with st.form("path_form", border=False):
            pc1, pc2 = st.columns([4, 1])
            typed = pc1.text_input("...or paste the full path of the schedule", value=ss.schedule or "",
                                   placeholder=os.path.join(default_folder, "Customer_Schedule.xlsx"), label_visibility="collapsed")
            if pc2.form_submit_button("Analyse", disabled=bool(cfg_err), width="stretch"):
                typed = typed.strip().strip('"')
                if not os.path.isfile(typed):
                    st.error(f"File not found: {typed}")
                else:
                    run_analysis(typed, [], "New schedule")
    with st.expander("...or upload the file (a copy is saved to a folder you choose, outputs go next to it)"):
        up = st.file_uploader("Customer schedule", type=["xlsx", "xlsm"], label_visibility="collapsed")
        folder = st.text_input("Save the upload and outputs in", value=default_folder)
        if st.button("Save and analyse", disabled=up is None or bool(cfg_err)):
            try:
                run_analysis(save_upload(up, folder), [], "Uploaded schedule")
            except OSError as e:
                st.error(f"Could not save to {folder}: {e}")

    if ss.last_error:
        st.error(ss.last_error)
    res = ss.res
    if res is None:
        st.info("No schedule analysed yet.")
        return

    wells = res["wells"]
    n = eng.status_counts(res)
    st.divider()
    st.subheader("2. Results")
    st.write(f"**Schedule:** `{ss.schedule}`")
    st.caption("Stage and Well Designs are evaluated well by well; a pad is imported only when every well on it is ready.")
    m = st.columns(4)
    m[0].metric("Wells", len(wells))
    m[1].metric("Stage Designs", f"{len(res['sds'])}", help=f"{sum(1 for w in wells if w['sd_ok'])} wells have a clean stage design")
    m[2].metric("Well Designs", f"{len(res['wds'])}", help=f"{sum(1 for w in wells if w['wd_ok'])} wells have a clean well design")
    m[3].metric("Pads imported", f"{sum(1 for p in res['pads'].values() if p['status'] == 'IMPORT')} / {len(res['pads'])}")
    m = st.columns(5)
    m[0].metric("Fully imported", n["IMPORTED"], help=eng.STATUS_TEXT["IMPORTED"])
    m[1].metric("Designs only (pad held)", n["DESIGNS ONLY"], help=eng.STATUS_TEXT["DESIGNS ONLY"])
    m[2].metric("Stage design only", n["STAGE DESIGN ONLY"], help=eng.STATUS_TEXT["STAGE DESIGN ONLY"])
    m[3].metric("Not imported", n["NOT IMPORTED"], help=eng.STATUS_TEXT["NOT IMPORTED"])
    m[4].metric("Accepted corrections", len(ss.accepted))

    st.markdown("**Output files** (saved automatically)")
    folder = os.path.dirname(ss.outputs[0]) if ss.outputs else ""
    fc1, fc2 = st.columns([4, 1])
    fc1.code(folder, language=None)
    if os.name == "nt" and fc2.button("Open folder", width="stretch"):
        os.startfile(folder)  # noqa: S606 - local desktop tool
    labels = {"PrePad_Stage_Design_Import": "PrePad import - Stage Design", "PrePad_Well_Design_Import": "PrePad import - Well Design",
              "PrePad_Pad_Import": "PrePad import - Pad", "PrePad_Error_Report": "Error report (internal)",
              "_QC_Client_Review_": "Client review copy (send to client)", "resolutions_": "Accepted corrections log"}
    cols = st.columns(3)
    for k, f in enumerate(ss.outputs):
        name = os.path.basename(f)
        label = next((v for key, v in labels.items() if key in name), name)
        with open(f, "rb") as fh:
            cols[k % 3].download_button(label, fh.read(), file_name=name, key=f"dl_{ss.run_id}_{k}", width="stretch",
                                        help=name)
    if not res["sds"]:
        st.warning("No well has a clean stage design, so the import files contain headers only.")

    t1, t2, t3, t4, t5 = st.tabs(["Wells not fully imported", "Pads", "Stage check", "Missing PrePad data", "Run history"])
    with t1:
        df = wells_table(res)
        if len(df):
            st.dataframe(df, width="stretch", hide_index=True, height=420)
        else:
            st.success("Every well is fully imported.")
    with t2:
        st.dataframe(pads_table(res), width="stretch", hide_index=True, height=420)
    with t3:
        st.dataframe(stage_table(res), width="stretch", hide_index=True, height=420)
    with t4:
        st.dataframe(missing_table(res), width="stretch", hide_index=True)
    with t5:
        st.dataframe(pd.DataFrame(ss.history), width="stretch", hide_index=True)

    st.divider()
    corrections_section()


def corrections_section():
    st.subheader("3. Review suggested corrections (optional)")
    st.caption("Accepted corrections are applied in memory only - the schedule file is never changed. The files are then "
               "regenerated with the corrected data, every change is logged (resolutions_*.json), and the client review copy "
               "shows each accepted correction as 'pending your confirmation'.")
    st.caption("**User Change** overrides the suggested value: type one value for every cell of the batch (e.g. 240), or "
               "`CELL=value; CELL=value` for chosen cells (required for the copy-and-paste batch; unlisted cells keep the "
               "suggestion). `blank` clears a cell. Entering a User Change accepts the batch.")
    batches = eng.collect_batches(ss.res)
    if ss.accepted:
        with st.expander(f"{len(ss.accepted)} correction(s) currently applied", expanded=False):
            st.dataframe(pd.DataFrame([{"Cell": a["cell"], "Pad": a["pad"], "Field": a["field"], "From": eng.fmt_blank(a["original"]),
                                        "To": eng.fmt_blank(a["new"]),
                                        "Source": "Your value (suggested " + eng.fmt_blank(a.get("suggested")) + ")"
                                        if a.get("user_override") else "Suggestion", "Check": a["check"], "Engineer": a.get("engineer"),
                                        "Accepted at": a.get("accepted_at")} for a in ss.accepted]),
                         width="stretch", hide_index=True)
            if st.button("Remove all accepted corrections and regenerate"):
                run_analysis(ss.schedule, [], "Corrections removed")
                st.rerun()
    if not batches:
        st.success("No suggested corrections left to review.")
    else:
        df = pd.DataFrame([{"Accept": False, "Batch": k + 1, "Check": b[0]["check"], "Likely cause": eng.LIKELY_CAUSE.get(b[0]["check"], ""),
                            "Field": b[0]["field"].replace("_", " "), "Cells": len(b),
                            "Where": ", ".join(i["cell"] for i in b[:6]) + (f" (+{len(b) - 6})" if len(b) > 6 else ""),
                            "Change": "; ".join(f"{i['cell']} {eng.fmt_blank(i['original'])} -> {eng.fmt_blank(i['new'])}" for i in b)
                            if b[0]["check"] == "W34" else f"{eng.fmt_blank(b[0]['original'])} -> {eng.fmt_blank(b[0]['new'])}",
                            "User Change": "",
                            "Basis": b[0]["basis"]} for k, b in enumerate(batches)])
        edited = st.data_editor(df, hide_index=True, width="stretch", key=f"batches_{ss.run_id}",
                                disabled=[c for c in df.columns if c not in ("Accept", "User Change")],
                                column_config={"Accept": st.column_config.CheckboxColumn(width="small"),
                                               "User Change": st.column_config.TextColumn(
                                                   "User Change", width="medium", help="Your value overrides the suggestion. One value for "
                                                   "the whole batch, or CELL=value; CELL=value. 'blank' clears the cell."),
                                               "Batch": st.column_config.NumberColumn(width="small"),
                                               "Cells": st.column_config.NumberColumn(width="small")})
        chosen, errors = [], []
        for k, b in enumerate(batches):
            raw = edited.at[k, "User Change"]
            txt = "" if raw is None or (isinstance(raw, float) and pd.isna(raw)) else str(raw).strip()
            if not (bool(edited.at[k, "Accept"]) or txt):
                continue
            items, errs = eng.apply_user_change(b, txt)
            errors += [f"Batch {k + 1}: {e}" for e in errs]
            if not errs:
                chosen.append(items)
        for e in errors:
            st.error(e)
        overridden = [i for b in chosen for i in b if i.get("user_override")]
        if overridden:
            st.info(f"{len(overridden)} cell(s) will use your value instead of the suggestion: "
                    + ", ".join(f"{i['cell']} -> {eng.fmt_blank(i['new'])}" for i in overridden[:8])
                    + (f" (+{len(overridden) - 8})" if len(overridden) > 8 else ""))
        cells = [i["cell"] for b in chosen for i in b]
        excl = st.multiselect("Exclude individual cells from the accepted batches (optional)", cells, key=f"excl_{ss.run_id}")
        c1, c2 = st.columns([2, 3])
        ss.engineer = c1.text_input("Engineer (recorded with each accepted correction)", value=ss.engineer)
        c2.write("")
        if c2.button(f"Apply {len(cells) - len(excl)} correction(s) and regenerate files", type="primary",
                     disabled=not cells or not ss.engineer.strip() or bool(errors)):
            stamp = dt.datetime.now().isoformat(timespec="seconds")
            new = [{**i, "engineer": ss.engineer.strip(), "accepted_at": stamp} for b in chosen for i in b if i["cell"] not in excl]
            merged = [a for a in ss.accepted if a["cell"] not in {x["cell"] for x in new}] + new
            before = (sum(1 for w in ss.res["wells"] if w["status"] == "IMPORTED"), len(ss.res["wds"]))
            run_analysis(ss.schedule, merged, f"{len(new)} correction(s) accepted")
            after = (sum(1 for w in ss.res["wells"] if w["status"] == "IMPORTED"), len(ss.res["wds"]))
            st.toast(f"Wells fully imported {before[0]} -> {after[0]}; well designs {before[1]} -> {after[1]}. New files saved.")
            st.rerun()

    with st.expander("Replay a previous resolutions file"):
        up = st.file_uploader("resolutions_*.json", type=["json"], key="res_upload", label_visibility="collapsed")
        if up is not None and st.button("Apply resolutions file"):
            try:
                items = json.loads(up.getvalue().decode("utf-8")).get("corrections", [])
            except (ValueError, AttributeError):
                st.error("Not a valid resolutions file.")
                return
            ok, skipped = eng.filter_resolutions(items, ss.schedule)
            for s_ in skipped:
                st.warning(f"Skipped {s_['cell']}: the schedule now holds '{s_['current']}', the correction was made against "
                           f"'{s_['original']}'.")
            run_analysis(ss.schedule, ok, f"Replayed {len(ok)} correction(s)")
            st.rerun()


# ------------------------------------------------------------------------------------------------
# CONFIGURATION TAB
# ------------------------------------------------------------------------------------------------

def changed_note(path, value):
    d = eng.DEFAULTS
    for p in path:
        d = d[p]
    return "" if value == d else f"  • changed (guidance default: {d})"


def rules_to_df(rules):
    rows = []
    for r in rules or []:
        row = {f: "" for f in eng.MATCH_FIELDS}
        for f, v in (r.get("match") or {}).items():
            row[f] = "; ".join(map(str, v)) if isinstance(v, list) else ("" if v is None else str(v))
        row["value"] = r.get("value") or ""
        rows.append(row)
    if not rows:     # one empty row to type into; a value with no match columns becomes the default rule
        rows.append({**{f: "" for f in eng.MATCH_FIELDS}, "value": ""})
    return pd.DataFrame(rows, columns=eng.MATCH_FIELDS + ["value"])


def df_to_rules(df):
    rules = []
    for rec in df.to_dict("records"):
        def val(x):
            return "" if x is None or (isinstance(x, float) and pd.isna(x)) else str(x).strip()
        match = {}
        for f in eng.MATCH_FIELDS:
            v = val(rec.get(f))
            if v:
                parts = [p_.strip() for p_ in v.split(";") if p_.strip()]
                match[f] = parts if len(parts) > 1 else parts[0]
        value = val(rec.get("value"))
        if match or value:
            rules.append({"match": match, "value": value})
    return rules


def config_tab():
    cfg = ss.cfg
    v = ss.cfg_ver
    before = json.dumps(clean_cfg(cfg), sort_keys=True, default=str)
    H = eng.CONFIG_HELP
    st.subheader("Configuration")
    st.caption(f"Pre-populated with the built-in guidance. Override any value, then **Save** to keep it for future sessions "
               f"(file: `{CONFIG_PATH}`). Changes apply to the next analysis.")
    if ss.get("cfg_warning"):
        st.warning(ss.cfg_warning)

    b = st.columns(6)
    if b[0].button("Save configuration", type="primary", width="stretch"):
        ok, err = validated_cfg()
        if err:
            st.error(err)
        else:
            with open(CONFIG_PATH, "w", encoding="utf-8") as f:
                json.dump(clean_cfg(cfg), f, indent=2)
            st.toast(f"Saved to {CONFIG_PATH}")
    if b[1].button("Reload saved", width="stretch"):
        ss.cfg, ss.cfg_warning = load_cfg_file()
        bump_cfg()
        st.rerun()
    if b[2].button("Reset to guidance", width="stretch", help="Built-in defaults; your saved file is unchanged until you Save"):
        ss.cfg = clean_cfg(eng.DEFAULTS)
        bump_cfg()
        st.rerun()
    b[3].download_button("Download JSON", json.dumps(clean_cfg(cfg), indent=2), file_name="prepad_config.json",
                         mime="application/json", width="stretch")
    if b[4].button("Re-run analysis", width="stretch", disabled=ss.schedule is None,
                   help="Analyse the current schedule again with this configuration"):
        run_analysis(ss.schedule, ss.accepted, "Configuration changed")
    with b[5].popover("Load JSON file", width="stretch"):
        up = st.file_uploader("Config JSON", type=["json"], key=f"cfg_up_{v}", label_visibility="collapsed")
        if up is not None:
            try:
                ss.cfg = clean_cfg(eng.settings_from_dict(json.loads(up.getvalue().decode("utf-8"))))
                bump_cfg()
                st.rerun()
            except (ValueError, eng.ConfigError) as e:
                st.error(f"Not loaded: {e}")

    status_box = st.empty()       # filled at the end, after the widgets below have updated the configuration

    # ---- thresholds
    st.markdown("#### Screening thresholds")
    st.caption("Screens for flagging data, not design limits.")
    t = cfg["thresholds"]
    c = st.columns(3)
    t["ll_screen_fraction"] = c[0].number_input("LL screen (fraction of median)", 0.0, 1.0, float(t["ll_screen_fraction"]), 0.01,
                                                format="%.2f", key=f"t1_{v}", help=H["thresholds"]["ll_screen_fraction"])
    c[0].caption(H["thresholds"]["ll_screen_fraction"] + changed_note(["thresholds", "ll_screen_fraction"], t["ll_screen_fraction"]))
    t["stage_count_min"] = int(c[1].number_input("Minimum stages per well", 1, 1000, int(t["stage_count_min"]), 1, key=f"t2_{v}"))
    c[1].caption(H["thresholds"]["stage_count_min"] + changed_note(["thresholds", "stage_count_min"], t["stage_count_min"]))
    t["stage_count_max"] = int(c[2].number_input("Maximum stages per well", 1, 2000, int(t["stage_count_max"]), 1, key=f"t3_{v}"))
    c[2].caption(H["thresholds"]["stage_count_max"] + changed_note(["thresholds", "stage_count_max"], t["stage_count_max"]))
    c = st.columns(3)
    t["spe_min_stage_spacing_ft"] = c[0].number_input("SPE minimum stage spacing (ft)", 0.0, 2000.0, float(t["spe_min_stage_spacing_ft"]),
                                                      5.0, key=f"t4_{v}")
    c[0].caption(H["thresholds"]["spe_min_stage_spacing_ft"] + changed_note(["thresholds", "spe_min_stage_spacing_ft"], t["spe_min_stage_spacing_ft"]))
    for col, key, label in ((c[1], "ll_min_ft", "Absolute minimum LL (ft)"), (c[2], "ll_max_ft", "Absolute maximum LL (ft)")):
        on = col.checkbox(f"Use {label.lower()}", value=t[key] is not None, key=f"{key}_on_{v}")
        if on:
            t[key] = col.number_input(label, 1.0, 100000.0, float(t[key] or (1000.0 if key == "ll_min_ft" else 20000.0)), 500.0,
                                      key=f"{key}_{v}")
        else:
            t[key] = None
        col.caption(H["thresholds"][key] + changed_note(["thresholds", key], t[key]))

    # ---- settings
    st.markdown("#### Settings")
    s_ = cfg["settings"]
    Hs = H["settings"]
    c = st.columns(3)
    s_["pending_design_blocks_import"] = c[0].toggle("'Pending Review' designs block import", value=bool(s_["pending_design_blocks_import"]),
                                                     key=f"s1_{v}")
    c[0].caption(Hs["pending_design_blocks_import"] + changed_note(["settings", "pending_design_blocks_import"], s_["pending_design_blocks_import"]))
    s_["pad_name_pattern"] = c[1].text_input("Pad name pattern", s_["pad_name_pattern"], key=f"s2_{v}")
    c[1].caption(Hs["pad_name_pattern"] + changed_note(["settings", "pad_name_pattern"], s_["pad_name_pattern"]))
    opts = ["frac_start", "completions_start"]
    s_["start_date_source"] = c[2].selectbox("Pad Start Date from", opts, opts.index(s_["start_date_source"]), key=f"s3_{v}")
    c[2].caption(Hs["start_date_source"] + changed_note(["settings", "start_date_source"], s_["start_date_source"]))
    c = st.columns(3)
    s_["start_date_utc_offset"] = c[0].text_input("Start Date UTC offset", s_["start_date_utc_offset"], key=f"s4_{v}")
    c[0].caption(Hs["start_date_utc_offset"] + changed_note(["settings", "start_date_utc_offset"], s_["start_date_utc_offset"]))
    s_["date_order"] = c[1].selectbox("Numeric date order", ["MDY", "DMY"], ["MDY", "DMY"].index(s_["date_order"]), key=f"s5_{v}")
    c[1].caption(Hs["date_order"] + changed_note(["settings", "date_order"], s_["date_order"]))
    s_["schedule_glob"] = c[2].text_input("Schedule file pattern", s_["schedule_glob"], key=f"s6_{v}")
    c[2].caption(Hs["schedule_glob"] + changed_note(["settings", "schedule_glob"], s_["schedule_glob"]))
    c = st.columns(3)
    for col, key, label, options in ((c[0], "stage_fluid_mode", "Fluid Loading Value or Ratio", ["Loading", "Ratio"]),
                                     (c[1], "stage_sand_fluid_unit", "Sand and Fluid Unit", ["Length", "Stage"]),
                                     (c[2], "stage_spacing_unit", "Spacing Unit", ["Cluster", "Stage"])):
        cur = s_[key] if s_[key] in options else options[0]
        s_[key] = col.selectbox(label, options, options.index(cur), key=f"{key}_{v}")
        col.caption(Hs[key] + changed_note(["settings", key], s_[key]))
    c = st.columns(2)
    s_["default_folder"] = c[0].text_input("Default schedule folder", s_["default_folder"], key=f"s7_{v}")
    c[0].caption(Hs["default_folder"] + changed_note(["settings", "default_folder"], s_["default_folder"]))
    s_["output_subfolder"] = c[1].text_input("Output subfolder", s_["output_subfolder"], key=f"s8_{v}")
    c[1].caption(Hs["output_subfolder"] + changed_note(["settings", "output_subfolder"], s_["output_subfolder"]))

    # ---- bench aliases
    st.markdown("#### Bench naming convention")
    st.caption(H["bench_aliases"])
    bdf = pd.DataFrame([{"Schedule value": k, "Standard name": val} for k, val in cfg["bench_aliases"].items()],
                       columns=["Schedule value", "Standard name"])
    bed = st.data_editor(bdf, num_rows="dynamic", hide_index=True, key=f"bench_{v}")
    cfg["bench_aliases"] = {str(r["Schedule value"]).strip(): str(r["Standard name"]).strip() for r in bed.to_dict("records")
                            if r["Schedule value"] and not pd.isna(r["Schedule value"]) and r["Standard name"] and not pd.isna(r["Standard name"])}

    # ---- asset mapping
    st.markdown("#### PrePad asset mapping")
    st.caption(H["asset_mapping"] + " Match columns left blank are ignored for that rule.")
    pc1, pc2 = st.columns([1, 3])
    if pc1.button("Pre-fill from current schedule", disabled=ss.schedule is None,
                  help="Adds one blank rule for every value found in the loaded schedule; existing rules are kept"):
        cfgv, e = validated_cfg()
        if not e:
            eng.activate(cfgv)
            tmpl = eng.config_template_dict(ss.schedule, dt.date.today())["asset_mapping"]
            for key, rules in tmpl.items():
                have = [json.dumps(r.get("match"), sort_keys=True) for r in cfg["asset_mapping"].get(key, [])]
                cfg["asset_mapping"][key] = cfg["asset_mapping"].get(key, []) + \
                    [r for r in rules if json.dumps(r["match"], sort_keys=True) not in have]
            bump_cfg()
            st.rerun()
    pc2.caption("Fill the 'value' column with the exact PrePad name. Match fields: " + ", ".join(eng.MATCH_FIELDS) + ".")
    for tpl, column, key in eng.ASSET_FIELDS:
        rules = cfg["asset_mapping"].get(key, [])
        n_active = sum(1 for r in rules if str(r.get("value") or "").strip())
        with st.expander(f"{tpl}: {column}  -  {n_active} active rule(s)", expanded=False):
            fallback = {"casing_design": "Without a rule: casing text from the schedule.",
                        "subsurface_equipment": "Without a rule: plug type from the schedule."}.get(key, "Without a rule: left blank.")
            st.caption(f"Config key `asset_mapping.{key}`. {fallback}")
            ed = st.data_editor(rules_to_df(rules), num_rows="dynamic", hide_index=True, width="stretch", key=f"am_{key}_{v}",
                                column_config={"value": st.column_config.TextColumn("PrePad value", width="medium")})
            cfg["asset_mapping"][key] = df_to_rules(ed)

    if json.dumps(clean_cfg(cfg), sort_keys=True, default=str) != before:
        st.rerun()                 # the Run tab (drawn first) must see the edited configuration straight away
    ok, err = validated_cfg()
    if err:
        status_box.error(err)
    else:
        status_box.success("Configuration is valid." + ("" if clean_cfg(cfg) == clean_cfg(eng.DEFAULTS) else
                                                         " Some values differ from the built-in guidance (marked 'changed')."))

    # ---- raw JSON
    with st.expander("Advanced: edit the configuration as JSON"):
        txt = st.text_area("JSON", json.dumps(clean_cfg(cfg), indent=2), height=420, key=f"json_{v}", label_visibility="collapsed")
        if st.button("Apply JSON"):
            try:
                ss.cfg = clean_cfg(eng.settings_from_dict(json.loads(txt)))
                bump_cfg()
                st.rerun()
            except (ValueError, eng.ConfigError) as e:
                st.error(f"Not applied: {e}")


# ------------------------------------------------------------------------------------------------
# HELP TAB
# ------------------------------------------------------------------------------------------------

def help_tab():
    st.subheader("How it works")
    st.markdown("""
1. **Select** the customer schedule (Browse, paste the path, or upload). It is analysed immediately and every output file
   is saved in the schedule's folder - nothing else to click.
2. **Review** the results: how far each well gets (stage design, well design, pad), the likely cause, pads, the
   stage-count check and the PrePad data still missing.
3. **Optionally accept** suggested corrections (e.g. LL 10 -> 10,000 ft, SPE spacing 25 -> 250 ft, fill-out errors), or type your own value
   in **User Change** to override a suggestion. The files are regenerated with the corrected data; the schedule itself is
   never changed. The logs and the client copy show both the suggestion and your value.
4. **Send** the *Client review copy* to the client. It is the schedule in its original layout with flagged cells highlighted,
   a comment on each, and columns for the reasoning, suggested correction and the client's response.
5. **Import** only after engineering sign-off and client confirmation.

**Rules.** Each ERROR holds the template it affects for that well. Stage Designs are written for every well whose stage
inputs are clean; Well Designs for every well whose stage design and well data are clean. The Pad file rolls these up:
PrePad imports whole pads, so a pad is written only when every well on it is ready for all three templates.
Import order: Stage Design, then Well Design, then Pad.
Nothing is corrected or defaulted unless an engineer accepts the correction. Thresholds are screens, not design limits.
Units are written as stated in the schedule.
""")
    st.markdown("**Output files**")
    st.dataframe(pd.DataFrame([
        {"File": "PrePad_Stage_Design_Import_<stamp>.xlsx", "Use": "PrePad import: one row per unique stage design from every well with clean stage inputs"},
        {"File": "PrePad_Well_Design_Import_<stamp>.xlsx", "Use": "PrePad import: one row per unique well design from every well with clean design data"},
        {"File": "PrePad_Pad_Import_<stamp>.xlsx", "Use": "PrePad import: pads whose wells are all ready (roll-up)"},
        {"File": "PrePad_Error_Report_<stamp>.xlsx", "Use": "Internal: every issue, cause, suggestion, stage check, asset mapping, missing data"},
        {"File": "<schedule>_QC_Client_Review_<stamp>.xlsx", "Use": "Send to the client for verification and approval"},
        {"File": "resolutions_<stamp>.json", "Use": "Log of accepted corrections; can be replayed on a later run"},
    ]), hide_index=True, width="stretch")
    cfg, err = validated_cfg()
    eng.activate(cfg or eng.settings_from_dict({}))
    st.markdown("**Check catalogue** (with the current thresholds)")
    st.dataframe(pd.DataFrame([{"Check": k, "Level": lv, "Scope": sc,
                                "Holds (if ERROR)": eng.CHECK_TEMPLATE.get(k) or ("Pad" if k.startswith("P") else "by field"),
                                "Likely cause": eng.LIKELY_CAUSE.get(k, ""), "Description": d}
                               for k, (lv, sc, d) in eng.CHECKS.items()]), hide_index=True, width="stretch", height=500)
    st.caption(f"Engine: prepad_clean_import.py v{eng.VERSION}  |  App folder: {APP_DIR}")


# ------------------------------------------------------------------------------------------------

def main():
    init_state()
    st.title("PrePad Intake QC")
    st.caption("Customer schedule -> checks -> PrePad import files (designs per well, pads rolled up), internal error report and client review copy.")
    tab_run, tab_cfg, tab_help = st.tabs(["Run", "Configuration", "Help"])
    with tab_run:
        run_tab()
    with tab_cfg:
        config_tab()
    with tab_help:
        help_tab()


main()
