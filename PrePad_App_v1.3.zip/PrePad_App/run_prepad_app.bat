@echo off
setlocal EnableExtensions
title PrePad Intake QC
cd /d "%~dp0"

rem ---------------------------------------------------------------------------
rem  PrePad Intake QC - double-click to start.
rem  First start: creates a private Python environment in .venv and installs
rem  the requirements (needs internet once). Later starts open in seconds.
rem  Close this window to stop the app.
rem ---------------------------------------------------------------------------

set "VENV_PY=%~dp0.venv\Scripts\python.exe"
if exist "%VENV_PY%" goto :start

set "PY="
where py >nul 2>nul && set "PY=py -3"
if defined PY goto :create
where python >nul 2>nul && set "PY=python"
if defined PY goto :create
echo.
echo  Python 3.11 or newer was not found on this computer.
echo  Install it from https://www.python.org/downloads/ and tick "Add python.exe to PATH",
echo  then double-click this file again.
echo.
pause
exit /b 1

:create
%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)"
if errorlevel 1 (
  echo.
  echo  This app needs Python 3.11 or newer. Found:
  %PY% --version
  echo  Install Python 3.11-3.13 from https://www.python.org/downloads/ and tick "Add python.exe to PATH",
  echo  then double-click this file again.
  echo.
  pause
  exit /b 1
)
echo  First start: setting up the app environment. This takes a minute or two...
%PY% -m venv "%~dp0.venv"
if errorlevel 1 goto :fail
"%VENV_PY%" -m pip install --upgrade pip --disable-pip-version-check -q
"%VENV_PY%" -m pip install -r "%~dp0requirements.txt" --disable-pip-version-check
if errorlevel 1 goto :fail
echo  Setup complete.

:start
echo.
echo  Starting PrePad Intake QC in your browser: http://localhost:8501
echo  Keep this window open while you use the app. Close it to stop the app.
echo.
rem  headless mode avoids Streamlit's first-run e-mail prompt; the browser is opened separately
start "" /b cmd /c "timeout /t 5 /nobreak >nul & start "" http://localhost:8501"
"%VENV_PY%" -m streamlit run "%~dp0prepad_app.py" --server.port 8501 --server.headless true
if errorlevel 1 goto :fail
exit /b 0

:fail
echo.
echo  Something went wrong - see the messages above.
echo  To rebuild the environment, delete the .venv folder next to this file and run it again.
echo.
pause
exit /b 1
